-- MySQL dump 10.13  Distrib 8.0.26, for Linux (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	8.0.26-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `craft_addresses`
--

DROP TABLE IF EXISTS `craft_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_addresses` (
  `id` int NOT NULL,
  `ownerId` int DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `craft_fk_qrpkckcsoguqpkysgyiayxiwfgogaymjkpir` (`ownerId`),
  CONSTRAINT `craft_fk_nucrptiuneuxpcbsvcqompxwcuhbsbijcctf` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_qrpkckcsoguqpkysgyiayxiwfgogaymjkpir` FOREIGN KEY (`ownerId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_addresses`
--

LOCK TABLES `craft_addresses` WRITE;
/*!40000 ALTER TABLE `craft_addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_announcements`
--

DROP TABLE IF EXISTS `craft_announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `craft_idx_dwicaivxzqyyirdcbftnlfghonbosudsbrrc` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `craft_idx_knyoclocrjgdfggggeglinqwlvqgouyqxfjn` (`dateRead`),
  KEY `craft_fk_kwuiycpiednfejeqpgderzouttgseuelaybi` (`pluginId`),
  CONSTRAINT `craft_fk_kwuiycpiednfejeqpgderzouttgseuelaybi` FOREIGN KEY (`pluginId`) REFERENCES `craft_plugins` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_urbonawnavopgxfenjvmiszzvpxlatgehdwh` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_announcements`
--

LOCK TABLES `craft_announcements` WRITE;
/*!40000 ALTER TABLE `craft_announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_assetindexdata`
--

DROP TABLE IF EXISTS `craft_assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_pmqqyljpiytniyxbxpgjvuqvdmkrgnpmfaaj` (`sessionId`,`volumeId`),
  KEY `craft_idx_ystaypnlbxzsegpmejqtjqxembjrxpetnayl` (`volumeId`),
  CONSTRAINT `craft_fk_rdknutrduesriffsutdskoivriklflcjdntq` FOREIGN KEY (`sessionId`) REFERENCES `craft_assetindexingsessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_xogacbpedmghmmqmojxeelozurtfgsfypsoo` FOREIGN KEY (`volumeId`) REFERENCES `craft_volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_assetindexdata`
--

LOCK TABLES `craft_assetindexdata` WRITE;
/*!40000 ALTER TABLE `craft_assetindexdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_assetindexdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_assetindexingsessions`
--

DROP TABLE IF EXISTS `craft_assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_assetindexingsessions`
--

LOCK TABLES `craft_assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `craft_assetindexingsessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_assets`
--

DROP TABLE IF EXISTS `craft_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `craft_idx_qbuujjxqkoordnbtgfhmdyabsxububkqtvps` (`filename`,`folderId`),
  KEY `craft_idx_gmxzgtyjryaklfzqhoyutqhbyvnnbssfhofk` (`folderId`),
  KEY `craft_idx_rhaismgtqonstvazmmfxvrhrcvdmlsfqtogr` (`volumeId`),
  KEY `craft_fk_awdroupmpdyxdxevetgjoiicjnhuxovohsso` (`uploaderId`),
  CONSTRAINT `craft_fk_awdroupmpdyxdxevetgjoiicjnhuxovohsso` FOREIGN KEY (`uploaderId`) REFERENCES `craft_users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_fk_bccodnkvqodchettuzyxpzxlgawhkumgfkac` FOREIGN KEY (`folderId`) REFERENCES `craft_volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_iazjmqlfnexeuqxphftdwwlpnwdhjoqflppq` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_micsnkygbyxzxvztdfeouneeshncffkxgxfr` FOREIGN KEY (`volumeId`) REFERENCES `craft_volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_assets`
--

LOCK TABLES `craft_assets` WRITE;
/*!40000 ALTER TABLE `craft_assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_categories`
--

DROP TABLE IF EXISTS `craft_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `craft_idx_piodqmsocfhwhcadckjbekwlppvsgpwbhhmy` (`groupId`),
  KEY `craft_fk_wpigtoivrhnlrdpwbmpnowgbzhwusfqiywda` (`parentId`),
  CONSTRAINT `craft_fk_wpigtoivrhnlrdpwbmpnowgbzhwusfqiywda` FOREIGN KEY (`parentId`) REFERENCES `craft_categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_fk_xqfrpyajdzzebeskldpnraboupwuorvabdkb` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_ycfkanbbhdesixmopttjixalyuxzcwbrjxhw` FOREIGN KEY (`groupId`) REFERENCES `craft_categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_categories`
--

LOCK TABLES `craft_categories` WRITE;
/*!40000 ALTER TABLE `craft_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_categorygroups`
--

DROP TABLE IF EXISTS `craft_categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_rmpirclpaochjbdljdxpmnfkwrprkfwymtwd` (`name`),
  KEY `craft_idx_bdawcqaxflotpnymedrkxulbunbjhsdcjmol` (`handle`),
  KEY `craft_idx_uakbyrgfljxlvzouwytltcomzthibafirskb` (`structureId`),
  KEY `craft_idx_sqkvhvjosmpxmrajiimjllpohfveibvutcgo` (`fieldLayoutId`),
  KEY `craft_idx_wscwsekbwqmcqktbxowhkacifggytspmgxfd` (`dateDeleted`),
  CONSTRAINT `craft_fk_nvedsbmmzngfambsiwklujzuhxtybbcqsspk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_fk_yfxfpwtborguskqigydombzwgrtlwvaitwuo` FOREIGN KEY (`structureId`) REFERENCES `craft_structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_categorygroups`
--

LOCK TABLES `craft_categorygroups` WRITE;
/*!40000 ALTER TABLE `craft_categorygroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_categorygroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_categorygroups_sites`
--

DROP TABLE IF EXISTS `craft_categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_dssjurrkmkvuxtlshuguelbsxpvykibdngqh` (`groupId`,`siteId`),
  KEY `craft_idx_ocqefkbnnfceonhrlrpbcnqldlqzmsnjsqjr` (`siteId`),
  CONSTRAINT `craft_fk_bjnygpqofwysyonqxkbnmzljnmcttqkutbgu` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_fk_uzeuyrqimvaubamxnqqwxmeiyrfedocfnlqz` FOREIGN KEY (`groupId`) REFERENCES `craft_categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_categorygroups_sites`
--

LOCK TABLES `craft_categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `craft_categorygroups_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_changedattributes`
--

DROP TABLE IF EXISTS `craft_changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `craft_idx_ivcltgikmqnqwfzldubrjyhdgozzbfrwkwei` (`elementId`,`siteId`,`dateUpdated`),
  KEY `craft_fk_qaciwrnggtbpwmrkrcbpaifbusqgexvkezpw` (`siteId`),
  KEY `craft_fk_vsbqeynadorlfdyydjwvsqwegrvpclhmoxii` (`userId`),
  CONSTRAINT `craft_fk_kypqyciejsthejbkxpafesratnotuucgqbha` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_fk_qaciwrnggtbpwmrkrcbpaifbusqgexvkezpw` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_fk_vsbqeynadorlfdyydjwvsqwegrvpclhmoxii` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_changedattributes`
--

LOCK TABLES `craft_changedattributes` WRITE;
/*!40000 ALTER TABLE `craft_changedattributes` DISABLE KEYS */;
INSERT INTO `craft_changedattributes` VALUES (1,1,'firstName','2022-06-28 13:14:10',0,1),(1,1,'fullName','2022-06-28 13:14:10',0,1),(1,1,'lastName','2022-06-28 13:14:10',0,1);
/*!40000 ALTER TABLE `craft_changedattributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_changedfields`
--

DROP TABLE IF EXISTS `craft_changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`),
  KEY `craft_idx_odfxavznkqiyzknfpzavlrrggzzibaeqznxx` (`elementId`,`siteId`,`dateUpdated`),
  KEY `craft_fk_taouastwuiyxuhwigkkdjdkquffxqvzyzgkz` (`siteId`),
  KEY `craft_fk_kgplzdotqmlmexquauerayjxqdhxmaqsixwp` (`fieldId`),
  KEY `craft_fk_lvnsccogyksffoitbhwcierfkfaklpoaggnl` (`userId`),
  CONSTRAINT `craft_fk_dtomqetcmcnwdukyzfujlvxjhxqpicjfoyfn` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_fk_kgplzdotqmlmexquauerayjxqdhxmaqsixwp` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_fk_lvnsccogyksffoitbhwcierfkfaklpoaggnl` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `craft_fk_taouastwuiyxuhwigkkdjdkquffxqvzyzgkz` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_changedfields`
--

LOCK TABLES `craft_changedfields` WRITE;
/*!40000 ALTER TABLE `craft_changedfields` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_changedfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_content`
--

DROP TABLE IF EXISTS `craft_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_content` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_metaKeywords_covufsov` text,
  `field_metaDescription_ipyidism` varchar(800) DEFAULT NULL,
  `field_pageTitle_tzvpmbrm` varchar(400) DEFAULT NULL,
  `field_copyright_ozgqnamt` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_qqbugwqzmndvgfytruwfglkgtseytnosodzo` (`elementId`,`siteId`),
  KEY `craft_idx_krjoejotfeiacpbygypksntlpdpvbcxflfwh` (`siteId`),
  KEY `craft_idx_paesvxzgrypksszzjfhqvobhyzkmghdkfnye` (`title`),
  CONSTRAINT `craft_fk_lppdfzevlmkwvcuhydpmgrqwkoabjefbtbru` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_vzobhahkgrveejnemsornrdwijtqcbhxuwzc` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_content`
--

LOCK TABLES `craft_content` WRITE;
/*!40000 ALTER TABLE `craft_content` DISABLE KEYS */;
INSERT INTO `craft_content` VALUES (1,1,1,NULL,'2022-06-28 11:36:44','2022-06-28 13:14:10','b9e44d92-e70e-4783-a861-763be5b21ba3',NULL,NULL,NULL,NULL),(2,2,1,NULL,'2022-06-28 12:18:22','2022-06-28 12:43:05','835fa974-fc25-46d0-9602-0b347fc9829e',NULL,NULL,NULL,NULL),(3,3,1,NULL,'2022-06-28 13:17:06','2022-06-28 13:17:58','1c85f50b-9486-4274-99c2-47b5989330d3',NULL,NULL,NULL,NULL),(4,4,1,NULL,'2022-06-28 13:23:41','2022-06-28 13:23:41','95a0a57a-00f1-4f01-9746-2d6d120454e0',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `craft_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_craftidtokens`
--

DROP TABLE IF EXISTS `craft_craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_fk_casvhrevzlgjoyffgtsagotwpvblpjuemqbv` (`userId`),
  CONSTRAINT `craft_fk_casvhrevzlgjoyffgtsagotwpvblpjuemqbv` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_craftidtokens`
--

LOCK TABLES `craft_craftidtokens` WRITE;
/*!40000 ALTER TABLE `craft_craftidtokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_deprecationerrors`
--

DROP TABLE IF EXISTS `craft_deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text,
  `traces` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_excdamqcldegmzcnieoefwliawtlidfhjogt` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_deprecationerrors`
--

LOCK TABLES `craft_deprecationerrors` WRITE;
/*!40000 ALTER TABLE `craft_deprecationerrors` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_drafts`
--

DROP TABLE IF EXISTS `craft_drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `craft_idx_csptkwsxggukwhfomcyssvtgbkzsyxnwggyv` (`creatorId`,`provisional`),
  KEY `craft_idx_fyarcyinbsioidmgohhrrvmybmhftolmeury` (`saved`),
  KEY `craft_fk_dcxhiwglvjmeybwbvvzhmmjltwyeqexscccg` (`canonicalId`),
  CONSTRAINT `craft_fk_dcxhiwglvjmeybwbvvzhmmjltwyeqexscccg` FOREIGN KEY (`canonicalId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_mhjagkgpdxblhqoyhwcghighsvojxhxfavsg` FOREIGN KEY (`creatorId`) REFERENCES `craft_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_drafts`
--

LOCK TABLES `craft_drafts` WRITE;
/*!40000 ALTER TABLE `craft_drafts` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_elements`
--

DROP TABLE IF EXISTS `craft_elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_mwbfbkacaiurzjwhoauglfzqlkxnrlqlhosj` (`dateDeleted`),
  KEY `craft_idx_uncmxhzeyoqyxnjvixghfqhafqqclmzqlwmy` (`fieldLayoutId`),
  KEY `craft_idx_lgjkfgbffmnjiebomethvnfhowloahyywuol` (`type`),
  KEY `craft_idx_rwqjyjyzvomdyowbfazmmfhsslohlpvekioe` (`enabled`),
  KEY `craft_idx_zzkegfdbtfveudepewvsfubmsdojkhtvdvmi` (`archived`,`dateCreated`),
  KEY `craft_idx_onzopbizwgrawycvpbqqufkljjrisgotuozt` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `craft_idx_xgxfioapatluhjwtsbjtudaiphppanjkrxse` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `craft_fk_togpxyjsytwlfnfukdvgjhtgocrfrrddhzjm` (`canonicalId`),
  KEY `craft_fk_ycynngodbhusfizgpnmmeubizmbaapihlhyp` (`draftId`),
  KEY `craft_fk_npirptuhmxoodvoknjhfcefqpwvtqmdpkmcl` (`revisionId`),
  CONSTRAINT `craft_fk_npirptuhmxoodvoknjhfcefqpwvtqmdpkmcl` FOREIGN KEY (`revisionId`) REFERENCES `craft_revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_togpxyjsytwlfnfukdvgjhtgocrfrrddhzjm` FOREIGN KEY (`canonicalId`) REFERENCES `craft_elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_fk_wyndfgbrryksnamkmtflmbuoqggnaceeefae` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_fk_ycynngodbhusfizgpnmmeubizmbaapihlhyp` FOREIGN KEY (`draftId`) REFERENCES `craft_drafts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_elements`
--

LOCK TABLES `craft_elements` WRITE;
/*!40000 ALTER TABLE `craft_elements` DISABLE KEYS */;
INSERT INTO `craft_elements` VALUES (1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2022-06-28 11:36:44','2022-06-28 13:14:10',NULL,NULL,'ce40af9a-22ee-4207-af9e-01938f466e58'),(2,NULL,NULL,NULL,1,'craft\\elements\\GlobalSet',1,0,'2022-06-28 12:18:22','2022-06-28 12:43:05',NULL,NULL,'a68d529a-4653-4b28-af35-6065e57e89f8'),(3,NULL,NULL,NULL,8,'craft\\elements\\GlobalSet',1,0,'2022-06-28 13:17:06','2022-06-28 13:17:58',NULL,NULL,'f4e805a9-9a81-4e4c-9e7d-16508454929c'),(4,NULL,NULL,NULL,9,'craft\\elements\\GlobalSet',1,0,'2022-06-28 13:23:41','2022-06-28 13:23:41',NULL,NULL,'a8572e3c-e252-4543-be4d-2991b0da65f7');
/*!40000 ALTER TABLE `craft_elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_elements_sites`
--

DROP TABLE IF EXISTS `craft_elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_vcsnziupsayzhmxcsrjtwfxcnfpzufikjber` (`elementId`,`siteId`),
  KEY `craft_idx_ybaamhngklbfewdwjdgwupxccmtoqyhstznk` (`siteId`),
  KEY `craft_idx_njvehrbyozrusnyylqohmyqgsztuhupjpvxz` (`slug`,`siteId`),
  KEY `craft_idx_dzkuqboqobxfbyurilfrvrypqygzlwosirqk` (`enabled`),
  KEY `craft_idx_ouxdcyozpgkokhmbfeowsbhgqfwzanfbrrml` (`uri`,`siteId`),
  CONSTRAINT `craft_fk_fxqowefhegdpytgnkecjjbphpgoqcwqrqopx` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_fk_htgikkidfdrdzzerbtmzazshxxnkqafmjgaf` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_elements_sites`
--

LOCK TABLES `craft_elements_sites` WRITE;
/*!40000 ALTER TABLE `craft_elements_sites` DISABLE KEYS */;
INSERT INTO `craft_elements_sites` VALUES (1,1,1,NULL,NULL,1,'2022-06-28 11:36:44','2022-06-28 11:36:44','c8b0291c-2f47-4eeb-8d1c-ffd970392aa2'),(2,2,1,NULL,NULL,1,'2022-06-28 12:18:22','2022-06-28 12:18:22','8411997f-a200-4d82-a590-d148f1d0f2dd'),(3,3,1,NULL,NULL,1,'2022-06-28 13:17:06','2022-06-28 13:17:06','addc5883-b3ed-430f-9283-ead7783fa3c9'),(4,4,1,NULL,NULL,1,'2022-06-28 13:23:41','2022-06-28 13:23:41','dc649fb2-957b-411d-98b5-1938ed4685ec');
/*!40000 ALTER TABLE `craft_elements_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_entries`
--

DROP TABLE IF EXISTS `craft_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_entries` (
  `id` int NOT NULL,
  `sectionId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `authorId` int DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `craft_idx_qaoxunhlzrhxeicqrcgjpmsetubfnlztimzo` (`postDate`),
  KEY `craft_idx_yxuxqrstcgeysyytnozygxaohjzvolktbyve` (`expiryDate`),
  KEY `craft_idx_ohzwtcmaabougpssyntrhwvdjlnryyzfwrcq` (`authorId`),
  KEY `craft_idx_kinqqeixapeeelsajljuiamwkjdjeotzpkuc` (`sectionId`),
  KEY `craft_idx_mqkwsjqpcwbwskfyelnzzqghtybehmctsnbp` (`typeId`),
  KEY `craft_fk_fkkidiwmzknhecsssmhqezvuoijjgeaxmmmn` (`parentId`),
  CONSTRAINT `craft_fk_eytvjvurgwdbhskbuptppelezojcdbmuyojs` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_fkkidiwmzknhecsssmhqezvuoijjgeaxmmmn` FOREIGN KEY (`parentId`) REFERENCES `craft_entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_fk_jnfewfzeuxbyamtjncwigthdsvypdxdfrjai` FOREIGN KEY (`typeId`) REFERENCES `craft_entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_oiyvyspviyezakjmejtivkzbqhvdmlpsnbgi` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_shksapgkghwrsutpraefurtmpyhwfuwjatgy` FOREIGN KEY (`authorId`) REFERENCES `craft_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_entries`
--

LOCK TABLES `craft_entries` WRITE;
/*!40000 ALTER TABLE `craft_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_entrytypes`
--

DROP TABLE IF EXISTS `craft_entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_xsyenbkygfidruswlsdzbzwskihgokxeexno` (`name`,`sectionId`),
  KEY `craft_idx_sdhzohdnltejgwttpqxkfpdgljjpmavuhmfw` (`handle`,`sectionId`),
  KEY `craft_idx_rycprysxudurewasevvqgspzpdibueqmgjfw` (`sectionId`),
  KEY `craft_idx_plvsekgajblfgzxdyfnxtdjerhwrveugcgme` (`fieldLayoutId`),
  KEY `craft_idx_nkxsfsvuturqfrkqmdyiagwmoobxosxrtjds` (`dateDeleted`),
  CONSTRAINT `craft_fk_nresmixufiupxeasnuixbwvhfztxchltprsc` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_tawbjkkklcdtrtwtxovqavviievieuqbsnps` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_entrytypes`
--

LOCK TABLES `craft_entrytypes` WRITE;
/*!40000 ALTER TABLE `craft_entrytypes` DISABLE KEYS */;
INSERT INTO `craft_entrytypes` VALUES (1,1,2,'Default','default',1,'site',NULL,NULL,1,'2022-06-28 12:59:37','2022-06-28 12:59:37',NULL,'befee4b8-d4d1-4f12-b1b4-a813ee7c48ac'),(2,2,3,'Default','default',1,'site',NULL,NULL,1,'2022-06-28 13:00:49','2022-06-28 13:00:49',NULL,'38ac5001-1c65-41e7-bafb-0a90d162acb5'),(3,3,4,'Default','default',1,'site',NULL,NULL,1,'2022-06-28 13:02:47','2022-06-28 13:02:47','2022-06-28 13:03:15','fe694813-6da0-4ea3-9c76-ed260089d32b'),(4,4,5,'Default','default',1,'site',NULL,NULL,1,'2022-06-28 13:03:59','2022-06-28 13:03:59',NULL,'1c798ff3-3767-4943-af6a-f95199053004'),(5,5,6,'Default','default',1,'site',NULL,NULL,1,'2022-06-28 13:07:58','2022-06-28 13:07:58',NULL,'c835f74b-1a83-4ed8-9190-4c7cc5e5aae3'),(6,6,7,'Default','default',1,'site',NULL,NULL,1,'2022-06-28 13:08:39','2022-06-28 13:08:39',NULL,'7b181e68-36eb-4de8-bb15-c9bbe13bdc0a');
/*!40000 ALTER TABLE `craft_entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_fieldgroups`
--

DROP TABLE IF EXISTS `craft_fieldgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_fieldgroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_owliirhidnhzewutvqdsdgroqrychqxgiexo` (`name`),
  KEY `craft_idx_ojipryqpcsjkrtvlzpcrjsgzjyznwskmkdpi` (`dateDeleted`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_fieldgroups`
--

LOCK TABLES `craft_fieldgroups` WRITE;
/*!40000 ALTER TABLE `craft_fieldgroups` DISABLE KEYS */;
INSERT INTO `craft_fieldgroups` VALUES (1,'Common','2022-06-28 11:36:44','2022-06-28 11:36:44',NULL,'fefe114d-3863-429f-83c8-4e35865f3323'),(2,'Meta','2022-06-28 12:26:32','2022-06-28 12:26:32',NULL,'54a3e6eb-0887-4880-a798-4bf78095795c'),(3,'Footer','2022-06-28 13:17:14','2022-06-28 13:17:14',NULL,'f01d3ccf-b281-468d-8917-44495f1f7f66');
/*!40000 ALTER TABLE `craft_fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_fieldlayoutfields`
--

DROP TABLE IF EXISTS `craft_fieldlayoutfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_fieldlayoutfields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `layoutId` int NOT NULL,
  `tabId` int NOT NULL,
  `fieldId` int NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_oauniwdqqaqjxufoumjlmafilzgplyqmhqdb` (`layoutId`,`fieldId`),
  KEY `craft_idx_eynhmxfqtyjcgvandldategjfwopcltqotnm` (`sortOrder`),
  KEY `craft_idx_baltxlfjsebhehtnadwnygdmpnnbaapkoigz` (`tabId`),
  KEY `craft_idx_vautlrpxgmtrykhjdqimuycxnprqvlunpqha` (`fieldId`),
  CONSTRAINT `craft_fk_hixroivtzuspjqalwnwmskbepjgrqjhnurse` FOREIGN KEY (`layoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_jyijivnexnrzvrksygpzkunnfwendheqjbed` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_upvfzhgpubqyolbceimwmnvcswbfjqayrydk` FOREIGN KEY (`tabId`) REFERENCES `craft_fieldlayouttabs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_fieldlayoutfields`
--

LOCK TABLES `craft_fieldlayoutfields` WRITE;
/*!40000 ALTER TABLE `craft_fieldlayoutfields` DISABLE KEYS */;
INSERT INTO `craft_fieldlayoutfields` VALUES (6,1,4,3,0,0,'2022-06-28 12:43:05','2022-06-28 12:43:05','7e52a822-9672-4ecd-8c17-75fdd093e74d'),(7,1,4,2,0,1,'2022-06-28 12:43:05','2022-06-28 12:43:05','b808afc8-9e76-4f66-85d7-16db274249b6'),(8,1,4,1,0,2,'2022-06-28 12:43:05','2022-06-28 12:43:05','9a8e3daf-e4a3-4163-8b24-94687b40860b'),(9,8,11,4,0,0,'2022-06-28 13:17:58','2022-06-28 13:17:58','3be225a2-6577-43c2-a835-297cdbad2b0b'),(10,9,12,5,0,0,'2022-06-28 13:23:41','2022-06-28 13:23:41','07835d6b-da7a-432e-a618-740279ec4b32');
/*!40000 ALTER TABLE `craft_fieldlayoutfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_fieldlayouts`
--

DROP TABLE IF EXISTS `craft_fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_ytuqrarkgtpovdzemukzsgeolatjqpbawthb` (`dateDeleted`),
  KEY `craft_idx_dtnwvpybcbyrpzloriyallbmykoyudlgasif` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_fieldlayouts`
--

LOCK TABLES `craft_fieldlayouts` WRITE;
/*!40000 ALTER TABLE `craft_fieldlayouts` DISABLE KEYS */;
INSERT INTO `craft_fieldlayouts` VALUES (1,'craft\\elements\\GlobalSet','2022-06-28 12:28:47','2022-06-28 12:28:47',NULL,'ef6432a7-e2f8-45e5-930d-0cee96b22bea'),(2,'craft\\elements\\Entry','2022-06-28 12:59:37','2022-06-28 12:59:37',NULL,'e252f5ff-82ec-41e1-8245-5c36410571fe'),(3,'craft\\elements\\Entry','2022-06-28 13:00:49','2022-06-28 13:00:49',NULL,'5aec54e3-84f2-4c7d-badc-f563d37cf440'),(4,'craft\\elements\\Entry','2022-06-28 13:02:47','2022-06-28 13:02:47','2022-06-28 13:03:15','1c1338f3-2897-497b-a06b-cf2bb7c8b26a'),(5,'craft\\elements\\Entry','2022-06-28 13:03:59','2022-06-28 13:03:59',NULL,'a76e7502-c7f8-4303-8f60-3fc7b4d9d9e1'),(6,'craft\\elements\\Entry','2022-06-28 13:07:58','2022-06-28 13:07:58',NULL,'34818875-5fcc-49fe-8938-cafd80e9b13d'),(7,'craft\\elements\\Entry','2022-06-28 13:08:39','2022-06-28 13:08:39',NULL,'62f5c0ae-0abe-4379-8d26-6841530a89f9'),(8,'craft\\elements\\GlobalSet','2022-06-28 13:17:58','2022-06-28 13:17:58',NULL,'7a952482-636d-4693-8042-b850b9dfc0a0'),(9,'craft\\elements\\GlobalSet','2022-06-28 13:23:41','2022-06-28 13:23:41',NULL,'dff92c0e-282b-41c8-bbee-65d9eb00f727');
/*!40000 ALTER TABLE `craft_fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_fieldlayouttabs`
--

DROP TABLE IF EXISTS `craft_fieldlayouttabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_fieldlayouttabs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `layoutId` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `settings` text,
  `elements` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_kloejmtynnopmoiezmntonrautxgswkjvdsa` (`sortOrder`),
  KEY `craft_idx_kuxkobhujiexzswgdqjuqwnvlfxrzonvegij` (`layoutId`),
  CONSTRAINT `craft_fk_sbkxogshgsnpzrypqlxpqcludzgkfxqneffm` FOREIGN KEY (`layoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_fieldlayouttabs`
--

LOCK TABLES `craft_fieldlayouttabs` WRITE;
/*!40000 ALTER TABLE `craft_fieldlayouttabs` DISABLE KEYS */;
INSERT INTO `craft_fieldlayouttabs` VALUES (4,1,'Header','[]','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"7215f315-e5c6-4519-aeb5-ea17a92d5c17\",\"fieldUid\":\"4f9488d6-5cba-4c4b-9126-4f6370d90690\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"b5c7adc8-2f5d-44fd-9228-6b98b284922c\",\"fieldUid\":\"a29fa51b-961a-4881-b4b5-c3e066122601\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"77bbd686-6fc5-4d7e-a769-9cfb6771a6f4\",\"fieldUid\":\"e6ea26c6-b576-4b94-8b94-222e4396c11a\"}]',1,'2022-06-28 12:43:05','2022-06-28 12:43:05','f4dba190-5dfe-4bdc-9abb-4e8678f57422'),(5,2,'Content','[]','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"899af7fd-0dcb-415c-adc0-9fec7524a118\"}]',1,'2022-06-28 12:59:37','2022-06-28 12:59:37','2ffe5acc-34d6-463e-b161-118957fa4430'),(6,3,'Content','[]','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"06c3a706-36d6-46f7-8a1f-8a51c23f416e\"}]',1,'2022-06-28 13:00:49','2022-06-28 13:00:49','596c397b-7f55-44ec-8875-880cb2f7cc1f'),(7,4,'Content','[]','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"1e41bac3-5dc8-4b54-b124-a6c496d0a5fa\"}]',1,'2022-06-28 13:02:47','2022-06-28 13:02:47','ef41b886-1ce7-40ac-ade9-e37175a0cf86'),(8,5,'Content','[]','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"9156dee1-54ef-43a8-aeb1-387c70370f87\"}]',1,'2022-06-28 13:03:59','2022-06-28 13:03:59','c94333b6-de38-418e-96c5-ef3d02a16ddb'),(9,6,'Content','[]','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"fab76129-1bb9-477b-9a3a-89c09787b7cf\"}]',1,'2022-06-28 13:07:58','2022-06-28 13:07:58','adef476e-bd95-4481-a5c3-370694aeb628'),(10,7,'Content','[]','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"1e55667a-b4d2-4bce-b793-be5ddcb802ac\"}]',1,'2022-06-28 13:08:39','2022-06-28 13:08:39','17d23863-db30-48e7-aa5f-422d98e53bfa'),(11,8,'Footer','[]','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"1ab418c4-0d70-44cb-b3d5-8cd802d7fefc\",\"fieldUid\":\"d885ca37-56ce-4d56-bb1a-2e36c1406997\"}]',1,'2022-06-28 13:17:58','2022-06-28 13:17:58','f12ebd1c-c99f-4919-91ab-f1b3bf0a9c1f'),(12,9,'Navigation','[]','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"398fd1b9-1da0-4b02-a491-04f4df5894c9\",\"fieldUid\":\"41bf28b7-1ee9-4ef5-9b7a-17dd9926e345\"}]',1,'2022-06-28 13:23:41','2022-06-28 13:23:41','c0230390-018b-4e77-99f1-b4174c03a852');
/*!40000 ALTER TABLE `craft_fieldlayouttabs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_fields`
--

DROP TABLE IF EXISTS `craft_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_bzdsvkojdfdtimfbeuuxytjlpaozpflyfass` (`handle`,`context`),
  KEY `craft_idx_zenbaaciwoziyquiepevzphmdiunutfvitdt` (`groupId`),
  KEY `craft_idx_viydzoaqsfgeyqudolvwcearcwdhvzrtalyw` (`context`),
  CONSTRAINT `craft_fk_jwvsxyacktpwpjcxqhzltwndnfapkzvrnzmh` FOREIGN KEY (`groupId`) REFERENCES `craft_fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_fields`
--

LOCK TABLES `craft_fields` WRITE;
/*!40000 ALTER TABLE `craft_fields` DISABLE KEYS */;
INSERT INTO `craft_fields` VALUES (1,2,'Meta keywords','metaKeywords','global','covufsov',NULL,1,'none',NULL,'craft\\fields\\PlainText','{\"uiMode\":\"normal\",\"placeholder\":\"tag, tag\",\"code\":false,\"multiline\":false,\"initialRows\":4,\"charLimit\":null,\"byteLimit\":null,\"columnType\":null}','2022-06-28 12:27:34','2022-06-28 12:27:46','e6ea26c6-b576-4b94-8b94-222e4396c11a'),(2,2,'Meta description','metaDescription','global','ipyidism',NULL,1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":200,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":true,\"placeholder\":null,\"uiMode\":\"normal\"}','2022-06-28 12:38:51','2022-06-28 12:38:51','a29fa51b-961a-4881-b4b5-c3e066122601'),(3,2,'Page title','pageTitle','global','tzvpmbrm',NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":100,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2022-06-28 12:42:51','2022-06-28 12:42:51','4f9488d6-5cba-4c4b-9126-4f6370d90690'),(4,3,'Copyright','copyright','global','ozgqnamt',NULL,1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2022-06-28 13:17:39','2022-06-28 13:17:39','d885ca37-56ce-4d56-bb1a-2e36c1406997'),(5,1,'Navigation logo','navigationLogo','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":[\"image\"],\"defaultUploadLocationSource\":null,\"defaultUploadLocationSubpath\":null,\"localizeRelations\":false,\"maxRelations\":1,\"minRelations\":0,\"previewMode\":\"full\",\"restrictFiles\":true,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":null,\"restrictedLocationSubpath\":null,\"selectionCondition\":{\"elementType\":\"craft\\\\elements\\\\Asset\",\"fieldContext\":\"global\",\"class\":\"craft\\\\elements\\\\conditions\\\\assets\\\\AssetCondition\"},\"selectionLabel\":null,\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"source\":null,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"large\"}','2022-06-28 13:22:58','2022-06-28 13:25:22','41bf28b7-1ee9-4ef5-9b7a-17dd9926e345');
/*!40000 ALTER TABLE `craft_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_globalsets`
--

DROP TABLE IF EXISTS `craft_globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_puxcedqfuhrtrzsnxdxzeugnyqylvnjulrmm` (`name`),
  KEY `craft_idx_jbswnfyxvmfmqekohslmxftzxqtjdszbybma` (`handle`),
  KEY `craft_idx_eegnrtrumimhasnnlfulckprtjegbabvfqni` (`fieldLayoutId`),
  KEY `craft_idx_lzyrkjmeeinxavomnwuontgmxlzjlktefbrw` (`sortOrder`),
  CONSTRAINT `craft_fk_hdkmutvndisrapuijyqplpnsdirwwsrulvqm` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_fk_wsjglpzpzgwrkrbkbyumzgsubobxfazkcuws` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_globalsets`
--

LOCK TABLES `craft_globalsets` WRITE;
/*!40000 ALTER TABLE `craft_globalsets` DISABLE KEYS */;
INSERT INTO `craft_globalsets` VALUES (2,'Header','header',1,1,'2022-06-28 12:18:22','2022-06-28 12:40:09','a68d529a-4653-4b28-af35-6065e57e89f8'),(3,'Footer','footer',8,2,'2022-06-28 13:17:06','2022-06-28 13:17:58','f4e805a9-9a81-4e4c-9e7d-16508454929c'),(4,'Navigation','navigation',9,3,'2022-06-28 13:23:41','2022-06-28 13:23:41','cedde99d-71a7-4a93-ba03-0d1aebdc2157');
/*!40000 ALTER TABLE `craft_globalsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_gqlschemas`
--

DROP TABLE IF EXISTS `craft_gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` text,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_gqlschemas`
--

LOCK TABLES `craft_gqlschemas` WRITE;
/*!40000 ALTER TABLE `craft_gqlschemas` DISABLE KEYS */;
INSERT INTO `craft_gqlschemas` VALUES (1,'Public Schema','[]',1,'2022-06-28 12:44:53','2022-06-28 12:44:53','9e149db2-cbf2-4d0c-be84-673c44cf446e');
/*!40000 ALTER TABLE `craft_gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_gqltokens`
--

DROP TABLE IF EXISTS `craft_gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_wpvlrmarjlnlrcwdydjapaxevssdhlxusozg` (`accessToken`),
  UNIQUE KEY `craft_idx_sfczrufbbwpzbwapfpuigekdhnomwskposmg` (`name`),
  KEY `craft_fk_hkaklppteevohgatcfciwqohrhfzbwgfnwjh` (`schemaId`),
  CONSTRAINT `craft_fk_hkaklppteevohgatcfciwqohrhfzbwgfnwjh` FOREIGN KEY (`schemaId`) REFERENCES `craft_gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_gqltokens`
--

LOCK TABLES `craft_gqltokens` WRITE;
/*!40000 ALTER TABLE `craft_gqltokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_gqltokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_imagetransformindex`
--

DROP TABLE IF EXISTS `craft_imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_sddardkeaqtqrgufomvnwkpkcqusbfbfwcwr` (`assetId`,`transformString`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_imagetransformindex`
--

LOCK TABLES `craft_imagetransformindex` WRITE;
/*!40000 ALTER TABLE `craft_imagetransformindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_imagetransformindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_imagetransforms`
--

DROP TABLE IF EXISTS `craft_imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_zfefhxavhqwyadeibhnzwpcqaaqwzbcvlyxb` (`name`),
  KEY `craft_idx_ajaomkjjtjcdewedzvejapcvqkfsqkwkorlg` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_imagetransforms`
--

LOCK TABLES `craft_imagetransforms` WRITE;
/*!40000 ALTER TABLE `craft_imagetransforms` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_info`
--

DROP TABLE IF EXISTS `craft_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_info`
--

LOCK TABLES `craft_info` WRITE;
/*!40000 ALTER TABLE `craft_info` DISABLE KEYS */;
INSERT INTO `craft_info` VALUES (1,'4.1.0.2','4.0.0.9',0,'twpaukfmdmqb','3@gwwuefjwnm','2022-06-28 11:36:44','2022-06-30 09:13:29','7f52ac8c-15cc-4421-8552-e93a1a8f34d0');
/*!40000 ALTER TABLE `craft_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_matrixblocks`
--

DROP TABLE IF EXISTS `craft_matrixblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_matrixblocks` (
  `id` int NOT NULL,
  `primaryOwnerId` int NOT NULL,
  `fieldId` int NOT NULL,
  `typeId` int NOT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `craft_idx_ofagqfaqebenhlqudnbmbptoqbzenbhqiowm` (`primaryOwnerId`),
  KEY `craft_idx_wdxgwuhtxdkokufxqjgjpxsbsqyonasfpiia` (`fieldId`),
  KEY `craft_idx_hntwrggtfvljeevvmnqafqgqpincjrkhszef` (`typeId`),
  CONSTRAINT `craft_fk_juhesogtkfjjmcmtxpjvyvncuwvurwmhpmbf` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_oalrinjgepssctpgixkajmatunkqcwmpqrhf` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_psfppvxhkwqhzwfwvnfzpiwioyuupnfotpsb` FOREIGN KEY (`typeId`) REFERENCES `craft_matrixblocktypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_whgzmkgthktydltjzfxvlsvnffdyxmmuwhbc` FOREIGN KEY (`primaryOwnerId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_matrixblocks`
--

LOCK TABLES `craft_matrixblocks` WRITE;
/*!40000 ALTER TABLE `craft_matrixblocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_matrixblocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_matrixblocks_owners`
--

DROP TABLE IF EXISTS `craft_matrixblocks_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_matrixblocks_owners` (
  `blockId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`blockId`,`ownerId`),
  KEY `craft_fk_uesqeijheukfbfgtryyfjlazzksqgwnqfmju` (`ownerId`),
  CONSTRAINT `craft_fk_gymrnwtgxefltzgobasmuyhkghwwhkketnbb` FOREIGN KEY (`blockId`) REFERENCES `craft_matrixblocks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_uesqeijheukfbfgtryyfjlazzksqgwnqfmju` FOREIGN KEY (`ownerId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_matrixblocks_owners`
--

LOCK TABLES `craft_matrixblocks_owners` WRITE;
/*!40000 ALTER TABLE `craft_matrixblocks_owners` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_matrixblocks_owners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_matrixblocktypes`
--

DROP TABLE IF EXISTS `craft_matrixblocktypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_matrixblocktypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_zygdsonzbsbqqngoeelmnfmisedrtipovexu` (`name`,`fieldId`),
  KEY `craft_idx_hvwrwgseegwhpwkakhlcbetmmwlzhseuqtfv` (`handle`,`fieldId`),
  KEY `craft_idx_cwmaltzbzzxjafapystiytzzekxryqrgddpl` (`fieldId`),
  KEY `craft_idx_cmwvdhbuwhfimsefduhfahjxjjkjbufacwby` (`fieldLayoutId`),
  CONSTRAINT `craft_fk_hymrukpalnvsbrmgsthicodudqgxacdtskef` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_somqybslssfwcfmfraydvkvsxoiqgwsfcgoq` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_matrixblocktypes`
--

LOCK TABLES `craft_matrixblocktypes` WRITE;
/*!40000 ALTER TABLE `craft_matrixblocktypes` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_matrixblocktypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_migrations`
--

DROP TABLE IF EXISTS `craft_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_zrjocvolwhsqrezfjszleuwyntstotzeldjd` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_migrations`
--

LOCK TABLES `craft_migrations` WRITE;
/*!40000 ALTER TABLE `craft_migrations` DISABLE KEYS */;
INSERT INTO `craft_migrations` VALUES (1,'craft','Install','2022-06-28 11:36:45','2022-06-28 11:36:45','2022-06-28 11:36:45','158b2e11-639f-4e30-b704-a3b1de3b43be'),(2,'craft','m210121_145800_asset_indexing_changes','2022-06-28 11:36:45','2022-06-28 11:36:45','2022-06-28 11:36:45','8ad3f66a-120d-440d-a92e-6fedd20300ae'),(3,'craft','m210624_222934_drop_deprecated_tables','2022-06-28 11:36:45','2022-06-28 11:36:45','2022-06-28 11:36:45','c44f1dce-2efa-4dc7-a8bd-8fc5c93ad82e'),(4,'craft','m210724_180756_rename_source_cols','2022-06-28 11:36:45','2022-06-28 11:36:45','2022-06-28 11:36:45','e21dc930-c3cd-4b3e-a234-43aba1c02506'),(5,'craft','m210809_124211_remove_superfluous_uids','2022-06-28 11:36:45','2022-06-28 11:36:45','2022-06-28 11:36:45','5ff1e5b9-dc39-4223-a1cb-f931c39c4ade'),(6,'craft','m210817_014201_universal_users','2022-06-28 11:36:45','2022-06-28 11:36:45','2022-06-28 11:36:45','e11c270b-7c67-49d1-b930-4069dd76f2d7'),(7,'craft','m210904_132612_store_element_source_settings_in_project_config','2022-06-28 11:36:45','2022-06-28 11:36:45','2022-06-28 11:36:45','bde7c9d4-76c3-4296-93b3-d07c171918b6'),(8,'craft','m211115_135500_image_transformers','2022-06-28 11:36:45','2022-06-28 11:36:45','2022-06-28 11:36:45','9d160e6f-4f8c-4e51-b511-facfddc726a7'),(9,'craft','m211201_131000_filesystems','2022-06-28 11:36:45','2022-06-28 11:36:45','2022-06-28 11:36:45','9cb77ba6-dcae-4441-9f1e-a33482c1b619'),(10,'craft','m220103_043103_tab_conditions','2022-06-28 11:36:45','2022-06-28 11:36:45','2022-06-28 11:36:45','15ff52ea-ad37-4ffd-a4b3-471db89094b2'),(11,'craft','m220104_003433_asset_alt_text','2022-06-28 11:36:45','2022-06-28 11:36:45','2022-06-28 11:36:45','7ee2faac-7f72-4ff6-97cb-5ef77957b733'),(12,'craft','m220123_213619_update_permissions','2022-06-28 11:36:45','2022-06-28 11:36:45','2022-06-28 11:36:45','b8f4d949-ae58-4fcc-926a-12e3d0f7cc89'),(13,'craft','m220126_003432_addresses','2022-06-28 11:36:45','2022-06-28 11:36:45','2022-06-28 11:36:45','54cef7c8-0cf8-4a35-ac28-d3481e561708'),(14,'craft','m220209_095604_add_indexes','2022-06-28 11:36:45','2022-06-28 11:36:45','2022-06-28 11:36:45','2e3d294c-fdc2-46d6-84a2-555b8c5975e7'),(15,'craft','m220213_015220_matrixblocks_owners_table','2022-06-28 11:36:45','2022-06-28 11:36:45','2022-06-28 11:36:45','4d6ca20e-abe0-4b79-b3b0-7cc19413c3a4'),(16,'craft','m220214_000000_truncate_sessions','2022-06-28 11:36:45','2022-06-28 11:36:45','2022-06-28 11:36:45','4ab4de72-096a-4a6c-82f1-dbe2f413c31f'),(17,'craft','m220222_122159_full_names','2022-06-28 11:36:45','2022-06-28 11:36:45','2022-06-28 11:36:45','a3ae242a-0789-49b2-bc7a-582293d1a7a4'),(18,'craft','m220223_180559_nullable_address_owner','2022-06-28 11:36:45','2022-06-28 11:36:45','2022-06-28 11:36:45','ba5ed969-f5c8-4556-9344-d64ebbbfb60e'),(19,'craft','m220225_165000_transform_filesystems','2022-06-28 11:36:45','2022-06-28 11:36:45','2022-06-28 11:36:45','9ffcac88-512f-4e04-bfc6-3775f3538d26'),(20,'craft','m220309_152006_rename_field_layout_elements','2022-06-28 11:36:45','2022-06-28 11:36:45','2022-06-28 11:36:45','8c97334b-48a8-4365-b661-f933a16ba189'),(21,'craft','m220314_211928_field_layout_element_uids','2022-06-28 11:36:45','2022-06-28 11:36:45','2022-06-28 11:36:45','2b6b9b97-213d-469d-9e76-f901a9b6478c'),(22,'craft','m220316_123800_transform_fs_subpath','2022-06-28 11:36:45','2022-06-28 11:36:45','2022-06-28 11:36:45','867fac57-52a2-4ab6-ab05-7a8383cfb8eb'),(23,'craft','m220317_174250_release_all_jobs','2022-06-28 11:36:45','2022-06-28 11:36:45','2022-06-28 11:36:45','0d1db224-3cde-4198-b0dd-9f50c489129d'),(24,'craft','m220330_150000_add_site_gql_schema_components','2022-06-28 11:36:45','2022-06-28 11:36:45','2022-06-28 11:36:45','be962f2b-5810-4244-a82b-4921241ac1c8'),(25,'craft','m220413_024536_site_enabled_string','2022-06-28 11:36:45','2022-06-28 11:36:45','2022-06-28 11:36:45','b0ef8444-cea8-4af5-8101-ce00740b8a23');
/*!40000 ALTER TABLE `craft_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_plugins`
--

DROP TABLE IF EXISTS `craft_plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `licenseKeyStatus` enum('valid','trial','invalid','mismatched','astray','unknown') NOT NULL DEFAULT 'unknown',
  `licensedEdition` varchar(255) DEFAULT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_oeyjbawxdrsahwtvwzygwifzedyumundhqup` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_plugins`
--

LOCK TABLES `craft_plugins` WRITE;
/*!40000 ALTER TABLE `craft_plugins` DISABLE KEYS */;
INSERT INTO `craft_plugins` VALUES (1,'imager-x','4.1.1','4.0.0','trial',NULL,'2022-06-30 09:13:23','2022-06-30 09:13:23','2022-06-30 09:25:56','21c35d33-235e-4a5f-aa75-c2c53243cff5');
/*!40000 ALTER TABLE `craft_plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_projectconfig`
--

DROP TABLE IF EXISTS `craft_projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_projectconfig`
--

LOCK TABLES `craft_projectconfig` WRITE;
/*!40000 ALTER TABLE `craft_projectconfig` DISABLE KEYS */;
INSERT INTO `craft_projectconfig` VALUES ('dateModified','1656580409'),('elementSources.craft\\elements\\Entry.0.disabled','false'),('elementSources.craft\\elements\\Entry.0.key','\"*\"'),('elementSources.craft\\elements\\Entry.0.tableAttributes.0','\"section\"'),('elementSources.craft\\elements\\Entry.0.tableAttributes.1','\"postDate\"'),('elementSources.craft\\elements\\Entry.0.tableAttributes.2','\"expiryDate\"'),('elementSources.craft\\elements\\Entry.0.tableAttributes.3','\"author\"'),('elementSources.craft\\elements\\Entry.0.tableAttributes.4','\"link\"'),('elementSources.craft\\elements\\Entry.0.type','\"native\"'),('elementSources.craft\\elements\\Entry.1.heading','\"Navigation\"'),('elementSources.craft\\elements\\Entry.1.type','\"heading\"'),('elementSources.craft\\elements\\Entry.2.key','\"section:067b8079-ff86-45ca-b67b-b25b54f4245b\"'),('elementSources.craft\\elements\\Entry.2.type','\"native\"'),('elementSources.craft\\elements\\Entry.3.heading','\"Forms\"'),('elementSources.craft\\elements\\Entry.3.type','\"heading\"'),('elementSources.craft\\elements\\Entry.4.key','\"section:4ed30683-1a66-48b7-b6dd-0ab7ff4e6fce\"'),('elementSources.craft\\elements\\Entry.4.type','\"native\"'),('elementSources.craft\\elements\\Entry.5.key','\"section:2c1a6abd-a5ca-4a8c-8997-08da2721ba09\"'),('elementSources.craft\\elements\\Entry.5.type','\"native\"'),('elementSources.craft\\elements\\Entry.6.heading','\"Footer\"'),('elementSources.craft\\elements\\Entry.6.type','\"heading\"'),('elementSources.craft\\elements\\Entry.7.disabled','false'),('elementSources.craft\\elements\\Entry.7.key','\"section:301ad900-b843-483c-8c76-5a17b02fee48\"'),('elementSources.craft\\elements\\Entry.7.tableAttributes.0','\"postDate\"'),('elementSources.craft\\elements\\Entry.7.tableAttributes.1','\"expiryDate\"'),('elementSources.craft\\elements\\Entry.7.tableAttributes.2','\"author\"'),('elementSources.craft\\elements\\Entry.7.tableAttributes.3','\"link\"'),('elementSources.craft\\elements\\Entry.7.type','\"native\"'),('elementSources.craft\\elements\\Entry.8.key','\"section:c51a1d73-ff0d-4e87-bc02-619ac167057c\"'),('elementSources.craft\\elements\\Entry.8.type','\"native\"'),('email.fromEmail','\"admin@flowsa.com\"'),('email.fromName','\"craft4starter\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),('entryTypes.1c798ff3-3767-4943-af6a-f95199053004.fieldLayouts.a76e7502-c7f8-4303-8f60-3fc7b4d9d9e1.tabs.0.elements.0.autocapitalize','true'),('entryTypes.1c798ff3-3767-4943-af6a-f95199053004.fieldLayouts.a76e7502-c7f8-4303-8f60-3fc7b4d9d9e1.tabs.0.elements.0.autocomplete','false'),('entryTypes.1c798ff3-3767-4943-af6a-f95199053004.fieldLayouts.a76e7502-c7f8-4303-8f60-3fc7b4d9d9e1.tabs.0.elements.0.autocorrect','true'),('entryTypes.1c798ff3-3767-4943-af6a-f95199053004.fieldLayouts.a76e7502-c7f8-4303-8f60-3fc7b4d9d9e1.tabs.0.elements.0.class','null'),('entryTypes.1c798ff3-3767-4943-af6a-f95199053004.fieldLayouts.a76e7502-c7f8-4303-8f60-3fc7b4d9d9e1.tabs.0.elements.0.disabled','false'),('entryTypes.1c798ff3-3767-4943-af6a-f95199053004.fieldLayouts.a76e7502-c7f8-4303-8f60-3fc7b4d9d9e1.tabs.0.elements.0.id','null'),('entryTypes.1c798ff3-3767-4943-af6a-f95199053004.fieldLayouts.a76e7502-c7f8-4303-8f60-3fc7b4d9d9e1.tabs.0.elements.0.instructions','null'),('entryTypes.1c798ff3-3767-4943-af6a-f95199053004.fieldLayouts.a76e7502-c7f8-4303-8f60-3fc7b4d9d9e1.tabs.0.elements.0.label','null'),('entryTypes.1c798ff3-3767-4943-af6a-f95199053004.fieldLayouts.a76e7502-c7f8-4303-8f60-3fc7b4d9d9e1.tabs.0.elements.0.max','null'),('entryTypes.1c798ff3-3767-4943-af6a-f95199053004.fieldLayouts.a76e7502-c7f8-4303-8f60-3fc7b4d9d9e1.tabs.0.elements.0.min','null'),('entryTypes.1c798ff3-3767-4943-af6a-f95199053004.fieldLayouts.a76e7502-c7f8-4303-8f60-3fc7b4d9d9e1.tabs.0.elements.0.name','null'),('entryTypes.1c798ff3-3767-4943-af6a-f95199053004.fieldLayouts.a76e7502-c7f8-4303-8f60-3fc7b4d9d9e1.tabs.0.elements.0.orientation','null'),('entryTypes.1c798ff3-3767-4943-af6a-f95199053004.fieldLayouts.a76e7502-c7f8-4303-8f60-3fc7b4d9d9e1.tabs.0.elements.0.placeholder','null'),('entryTypes.1c798ff3-3767-4943-af6a-f95199053004.fieldLayouts.a76e7502-c7f8-4303-8f60-3fc7b4d9d9e1.tabs.0.elements.0.readonly','false'),('entryTypes.1c798ff3-3767-4943-af6a-f95199053004.fieldLayouts.a76e7502-c7f8-4303-8f60-3fc7b4d9d9e1.tabs.0.elements.0.requirable','false'),('entryTypes.1c798ff3-3767-4943-af6a-f95199053004.fieldLayouts.a76e7502-c7f8-4303-8f60-3fc7b4d9d9e1.tabs.0.elements.0.size','null'),('entryTypes.1c798ff3-3767-4943-af6a-f95199053004.fieldLayouts.a76e7502-c7f8-4303-8f60-3fc7b4d9d9e1.tabs.0.elements.0.step','null'),('entryTypes.1c798ff3-3767-4943-af6a-f95199053004.fieldLayouts.a76e7502-c7f8-4303-8f60-3fc7b4d9d9e1.tabs.0.elements.0.tip','null'),('entryTypes.1c798ff3-3767-4943-af6a-f95199053004.fieldLayouts.a76e7502-c7f8-4303-8f60-3fc7b4d9d9e1.tabs.0.elements.0.title','null'),('entryTypes.1c798ff3-3767-4943-af6a-f95199053004.fieldLayouts.a76e7502-c7f8-4303-8f60-3fc7b4d9d9e1.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.1c798ff3-3767-4943-af6a-f95199053004.fieldLayouts.a76e7502-c7f8-4303-8f60-3fc7b4d9d9e1.tabs.0.elements.0.uid','\"9156dee1-54ef-43a8-aeb1-387c70370f87\"'),('entryTypes.1c798ff3-3767-4943-af6a-f95199053004.fieldLayouts.a76e7502-c7f8-4303-8f60-3fc7b4d9d9e1.tabs.0.elements.0.warning','null'),('entryTypes.1c798ff3-3767-4943-af6a-f95199053004.fieldLayouts.a76e7502-c7f8-4303-8f60-3fc7b4d9d9e1.tabs.0.elements.0.width','100'),('entryTypes.1c798ff3-3767-4943-af6a-f95199053004.fieldLayouts.a76e7502-c7f8-4303-8f60-3fc7b4d9d9e1.tabs.0.name','\"Content\"'),('entryTypes.1c798ff3-3767-4943-af6a-f95199053004.fieldLayouts.a76e7502-c7f8-4303-8f60-3fc7b4d9d9e1.tabs.0.uid','\"c94333b6-de38-418e-96c5-ef3d02a16ddb\"'),('entryTypes.1c798ff3-3767-4943-af6a-f95199053004.handle','\"default\"'),('entryTypes.1c798ff3-3767-4943-af6a-f95199053004.hasTitleField','true'),('entryTypes.1c798ff3-3767-4943-af6a-f95199053004.name','\"Default\"'),('entryTypes.1c798ff3-3767-4943-af6a-f95199053004.section','\"067b8079-ff86-45ca-b67b-b25b54f4245b\"'),('entryTypes.1c798ff3-3767-4943-af6a-f95199053004.sortOrder','1'),('entryTypes.1c798ff3-3767-4943-af6a-f95199053004.titleFormat','null'),('entryTypes.1c798ff3-3767-4943-af6a-f95199053004.titleTranslationKeyFormat','null'),('entryTypes.1c798ff3-3767-4943-af6a-f95199053004.titleTranslationMethod','\"site\"'),('entryTypes.38ac5001-1c65-41e7-bafb-0a90d162acb5.fieldLayouts.5aec54e3-84f2-4c7d-badc-f563d37cf440.tabs.0.elements.0.autocapitalize','true'),('entryTypes.38ac5001-1c65-41e7-bafb-0a90d162acb5.fieldLayouts.5aec54e3-84f2-4c7d-badc-f563d37cf440.tabs.0.elements.0.autocomplete','false'),('entryTypes.38ac5001-1c65-41e7-bafb-0a90d162acb5.fieldLayouts.5aec54e3-84f2-4c7d-badc-f563d37cf440.tabs.0.elements.0.autocorrect','true'),('entryTypes.38ac5001-1c65-41e7-bafb-0a90d162acb5.fieldLayouts.5aec54e3-84f2-4c7d-badc-f563d37cf440.tabs.0.elements.0.class','null'),('entryTypes.38ac5001-1c65-41e7-bafb-0a90d162acb5.fieldLayouts.5aec54e3-84f2-4c7d-badc-f563d37cf440.tabs.0.elements.0.disabled','false'),('entryTypes.38ac5001-1c65-41e7-bafb-0a90d162acb5.fieldLayouts.5aec54e3-84f2-4c7d-badc-f563d37cf440.tabs.0.elements.0.id','null'),('entryTypes.38ac5001-1c65-41e7-bafb-0a90d162acb5.fieldLayouts.5aec54e3-84f2-4c7d-badc-f563d37cf440.tabs.0.elements.0.instructions','null'),('entryTypes.38ac5001-1c65-41e7-bafb-0a90d162acb5.fieldLayouts.5aec54e3-84f2-4c7d-badc-f563d37cf440.tabs.0.elements.0.label','null'),('entryTypes.38ac5001-1c65-41e7-bafb-0a90d162acb5.fieldLayouts.5aec54e3-84f2-4c7d-badc-f563d37cf440.tabs.0.elements.0.max','null'),('entryTypes.38ac5001-1c65-41e7-bafb-0a90d162acb5.fieldLayouts.5aec54e3-84f2-4c7d-badc-f563d37cf440.tabs.0.elements.0.min','null'),('entryTypes.38ac5001-1c65-41e7-bafb-0a90d162acb5.fieldLayouts.5aec54e3-84f2-4c7d-badc-f563d37cf440.tabs.0.elements.0.name','null'),('entryTypes.38ac5001-1c65-41e7-bafb-0a90d162acb5.fieldLayouts.5aec54e3-84f2-4c7d-badc-f563d37cf440.tabs.0.elements.0.orientation','null'),('entryTypes.38ac5001-1c65-41e7-bafb-0a90d162acb5.fieldLayouts.5aec54e3-84f2-4c7d-badc-f563d37cf440.tabs.0.elements.0.placeholder','null'),('entryTypes.38ac5001-1c65-41e7-bafb-0a90d162acb5.fieldLayouts.5aec54e3-84f2-4c7d-badc-f563d37cf440.tabs.0.elements.0.readonly','false'),('entryTypes.38ac5001-1c65-41e7-bafb-0a90d162acb5.fieldLayouts.5aec54e3-84f2-4c7d-badc-f563d37cf440.tabs.0.elements.0.requirable','false'),('entryTypes.38ac5001-1c65-41e7-bafb-0a90d162acb5.fieldLayouts.5aec54e3-84f2-4c7d-badc-f563d37cf440.tabs.0.elements.0.size','null'),('entryTypes.38ac5001-1c65-41e7-bafb-0a90d162acb5.fieldLayouts.5aec54e3-84f2-4c7d-badc-f563d37cf440.tabs.0.elements.0.step','null'),('entryTypes.38ac5001-1c65-41e7-bafb-0a90d162acb5.fieldLayouts.5aec54e3-84f2-4c7d-badc-f563d37cf440.tabs.0.elements.0.tip','null'),('entryTypes.38ac5001-1c65-41e7-bafb-0a90d162acb5.fieldLayouts.5aec54e3-84f2-4c7d-badc-f563d37cf440.tabs.0.elements.0.title','null'),('entryTypes.38ac5001-1c65-41e7-bafb-0a90d162acb5.fieldLayouts.5aec54e3-84f2-4c7d-badc-f563d37cf440.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.38ac5001-1c65-41e7-bafb-0a90d162acb5.fieldLayouts.5aec54e3-84f2-4c7d-badc-f563d37cf440.tabs.0.elements.0.uid','\"06c3a706-36d6-46f7-8a1f-8a51c23f416e\"'),('entryTypes.38ac5001-1c65-41e7-bafb-0a90d162acb5.fieldLayouts.5aec54e3-84f2-4c7d-badc-f563d37cf440.tabs.0.elements.0.warning','null'),('entryTypes.38ac5001-1c65-41e7-bafb-0a90d162acb5.fieldLayouts.5aec54e3-84f2-4c7d-badc-f563d37cf440.tabs.0.elements.0.width','100'),('entryTypes.38ac5001-1c65-41e7-bafb-0a90d162acb5.fieldLayouts.5aec54e3-84f2-4c7d-badc-f563d37cf440.tabs.0.name','\"Content\"'),('entryTypes.38ac5001-1c65-41e7-bafb-0a90d162acb5.fieldLayouts.5aec54e3-84f2-4c7d-badc-f563d37cf440.tabs.0.uid','\"596c397b-7f55-44ec-8875-880cb2f7cc1f\"'),('entryTypes.38ac5001-1c65-41e7-bafb-0a90d162acb5.handle','\"default\"'),('entryTypes.38ac5001-1c65-41e7-bafb-0a90d162acb5.hasTitleField','true'),('entryTypes.38ac5001-1c65-41e7-bafb-0a90d162acb5.name','\"Default\"'),('entryTypes.38ac5001-1c65-41e7-bafb-0a90d162acb5.section','\"c51a1d73-ff0d-4e87-bc02-619ac167057c\"'),('entryTypes.38ac5001-1c65-41e7-bafb-0a90d162acb5.sortOrder','1'),('entryTypes.38ac5001-1c65-41e7-bafb-0a90d162acb5.titleFormat','null'),('entryTypes.38ac5001-1c65-41e7-bafb-0a90d162acb5.titleTranslationKeyFormat','null'),('entryTypes.38ac5001-1c65-41e7-bafb-0a90d162acb5.titleTranslationMethod','\"site\"'),('entryTypes.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a.fieldLayouts.62f5c0ae-0abe-4379-8d26-6841530a89f9.tabs.0.elements.0.autocapitalize','true'),('entryTypes.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a.fieldLayouts.62f5c0ae-0abe-4379-8d26-6841530a89f9.tabs.0.elements.0.autocomplete','false'),('entryTypes.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a.fieldLayouts.62f5c0ae-0abe-4379-8d26-6841530a89f9.tabs.0.elements.0.autocorrect','true'),('entryTypes.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a.fieldLayouts.62f5c0ae-0abe-4379-8d26-6841530a89f9.tabs.0.elements.0.class','null'),('entryTypes.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a.fieldLayouts.62f5c0ae-0abe-4379-8d26-6841530a89f9.tabs.0.elements.0.disabled','false'),('entryTypes.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a.fieldLayouts.62f5c0ae-0abe-4379-8d26-6841530a89f9.tabs.0.elements.0.id','null'),('entryTypes.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a.fieldLayouts.62f5c0ae-0abe-4379-8d26-6841530a89f9.tabs.0.elements.0.instructions','null'),('entryTypes.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a.fieldLayouts.62f5c0ae-0abe-4379-8d26-6841530a89f9.tabs.0.elements.0.label','null'),('entryTypes.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a.fieldLayouts.62f5c0ae-0abe-4379-8d26-6841530a89f9.tabs.0.elements.0.max','null'),('entryTypes.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a.fieldLayouts.62f5c0ae-0abe-4379-8d26-6841530a89f9.tabs.0.elements.0.min','null'),('entryTypes.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a.fieldLayouts.62f5c0ae-0abe-4379-8d26-6841530a89f9.tabs.0.elements.0.name','null'),('entryTypes.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a.fieldLayouts.62f5c0ae-0abe-4379-8d26-6841530a89f9.tabs.0.elements.0.orientation','null'),('entryTypes.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a.fieldLayouts.62f5c0ae-0abe-4379-8d26-6841530a89f9.tabs.0.elements.0.placeholder','null'),('entryTypes.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a.fieldLayouts.62f5c0ae-0abe-4379-8d26-6841530a89f9.tabs.0.elements.0.readonly','false'),('entryTypes.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a.fieldLayouts.62f5c0ae-0abe-4379-8d26-6841530a89f9.tabs.0.elements.0.requirable','false'),('entryTypes.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a.fieldLayouts.62f5c0ae-0abe-4379-8d26-6841530a89f9.tabs.0.elements.0.size','null'),('entryTypes.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a.fieldLayouts.62f5c0ae-0abe-4379-8d26-6841530a89f9.tabs.0.elements.0.step','null'),('entryTypes.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a.fieldLayouts.62f5c0ae-0abe-4379-8d26-6841530a89f9.tabs.0.elements.0.tip','null'),('entryTypes.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a.fieldLayouts.62f5c0ae-0abe-4379-8d26-6841530a89f9.tabs.0.elements.0.title','null'),('entryTypes.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a.fieldLayouts.62f5c0ae-0abe-4379-8d26-6841530a89f9.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a.fieldLayouts.62f5c0ae-0abe-4379-8d26-6841530a89f9.tabs.0.elements.0.uid','\"1e55667a-b4d2-4bce-b793-be5ddcb802ac\"'),('entryTypes.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a.fieldLayouts.62f5c0ae-0abe-4379-8d26-6841530a89f9.tabs.0.elements.0.warning','null'),('entryTypes.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a.fieldLayouts.62f5c0ae-0abe-4379-8d26-6841530a89f9.tabs.0.elements.0.width','100'),('entryTypes.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a.fieldLayouts.62f5c0ae-0abe-4379-8d26-6841530a89f9.tabs.0.name','\"Content\"'),('entryTypes.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a.fieldLayouts.62f5c0ae-0abe-4379-8d26-6841530a89f9.tabs.0.uid','\"17d23863-db30-48e7-aa5f-422d98e53bfa\"'),('entryTypes.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a.handle','\"default\"'),('entryTypes.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a.hasTitleField','true'),('entryTypes.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a.name','\"Default\"'),('entryTypes.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a.section','\"2c1a6abd-a5ca-4a8c-8997-08da2721ba09\"'),('entryTypes.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a.sortOrder','1'),('entryTypes.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a.titleFormat','null'),('entryTypes.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a.titleTranslationKeyFormat','null'),('entryTypes.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a.titleTranslationMethod','\"site\"'),('entryTypes.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac.fieldLayouts.e252f5ff-82ec-41e1-8245-5c36410571fe.tabs.0.elements.0.autocapitalize','true'),('entryTypes.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac.fieldLayouts.e252f5ff-82ec-41e1-8245-5c36410571fe.tabs.0.elements.0.autocomplete','false'),('entryTypes.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac.fieldLayouts.e252f5ff-82ec-41e1-8245-5c36410571fe.tabs.0.elements.0.autocorrect','true'),('entryTypes.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac.fieldLayouts.e252f5ff-82ec-41e1-8245-5c36410571fe.tabs.0.elements.0.class','null'),('entryTypes.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac.fieldLayouts.e252f5ff-82ec-41e1-8245-5c36410571fe.tabs.0.elements.0.disabled','false'),('entryTypes.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac.fieldLayouts.e252f5ff-82ec-41e1-8245-5c36410571fe.tabs.0.elements.0.id','null'),('entryTypes.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac.fieldLayouts.e252f5ff-82ec-41e1-8245-5c36410571fe.tabs.0.elements.0.instructions','null'),('entryTypes.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac.fieldLayouts.e252f5ff-82ec-41e1-8245-5c36410571fe.tabs.0.elements.0.label','null'),('entryTypes.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac.fieldLayouts.e252f5ff-82ec-41e1-8245-5c36410571fe.tabs.0.elements.0.max','null'),('entryTypes.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac.fieldLayouts.e252f5ff-82ec-41e1-8245-5c36410571fe.tabs.0.elements.0.min','null'),('entryTypes.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac.fieldLayouts.e252f5ff-82ec-41e1-8245-5c36410571fe.tabs.0.elements.0.name','null'),('entryTypes.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac.fieldLayouts.e252f5ff-82ec-41e1-8245-5c36410571fe.tabs.0.elements.0.orientation','null'),('entryTypes.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac.fieldLayouts.e252f5ff-82ec-41e1-8245-5c36410571fe.tabs.0.elements.0.placeholder','null'),('entryTypes.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac.fieldLayouts.e252f5ff-82ec-41e1-8245-5c36410571fe.tabs.0.elements.0.readonly','false'),('entryTypes.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac.fieldLayouts.e252f5ff-82ec-41e1-8245-5c36410571fe.tabs.0.elements.0.requirable','false'),('entryTypes.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac.fieldLayouts.e252f5ff-82ec-41e1-8245-5c36410571fe.tabs.0.elements.0.size','null'),('entryTypes.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac.fieldLayouts.e252f5ff-82ec-41e1-8245-5c36410571fe.tabs.0.elements.0.step','null'),('entryTypes.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac.fieldLayouts.e252f5ff-82ec-41e1-8245-5c36410571fe.tabs.0.elements.0.tip','null'),('entryTypes.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac.fieldLayouts.e252f5ff-82ec-41e1-8245-5c36410571fe.tabs.0.elements.0.title','null'),('entryTypes.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac.fieldLayouts.e252f5ff-82ec-41e1-8245-5c36410571fe.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac.fieldLayouts.e252f5ff-82ec-41e1-8245-5c36410571fe.tabs.0.elements.0.uid','\"899af7fd-0dcb-415c-adc0-9fec7524a118\"'),('entryTypes.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac.fieldLayouts.e252f5ff-82ec-41e1-8245-5c36410571fe.tabs.0.elements.0.warning','null'),('entryTypes.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac.fieldLayouts.e252f5ff-82ec-41e1-8245-5c36410571fe.tabs.0.elements.0.width','100'),('entryTypes.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac.fieldLayouts.e252f5ff-82ec-41e1-8245-5c36410571fe.tabs.0.name','\"Content\"'),('entryTypes.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac.fieldLayouts.e252f5ff-82ec-41e1-8245-5c36410571fe.tabs.0.uid','\"2ffe5acc-34d6-463e-b161-118957fa4430\"'),('entryTypes.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac.handle','\"default\"'),('entryTypes.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac.hasTitleField','true'),('entryTypes.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac.name','\"Default\"'),('entryTypes.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac.section','\"301ad900-b843-483c-8c76-5a17b02fee48\"'),('entryTypes.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac.sortOrder','1'),('entryTypes.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac.titleFormat','null'),('entryTypes.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac.titleTranslationKeyFormat','null'),('entryTypes.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac.titleTranslationMethod','\"site\"'),('entryTypes.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3.fieldLayouts.34818875-5fcc-49fe-8938-cafd80e9b13d.tabs.0.elements.0.autocapitalize','true'),('entryTypes.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3.fieldLayouts.34818875-5fcc-49fe-8938-cafd80e9b13d.tabs.0.elements.0.autocomplete','false'),('entryTypes.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3.fieldLayouts.34818875-5fcc-49fe-8938-cafd80e9b13d.tabs.0.elements.0.autocorrect','true'),('entryTypes.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3.fieldLayouts.34818875-5fcc-49fe-8938-cafd80e9b13d.tabs.0.elements.0.class','null'),('entryTypes.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3.fieldLayouts.34818875-5fcc-49fe-8938-cafd80e9b13d.tabs.0.elements.0.disabled','false'),('entryTypes.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3.fieldLayouts.34818875-5fcc-49fe-8938-cafd80e9b13d.tabs.0.elements.0.id','null'),('entryTypes.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3.fieldLayouts.34818875-5fcc-49fe-8938-cafd80e9b13d.tabs.0.elements.0.instructions','null'),('entryTypes.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3.fieldLayouts.34818875-5fcc-49fe-8938-cafd80e9b13d.tabs.0.elements.0.label','null'),('entryTypes.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3.fieldLayouts.34818875-5fcc-49fe-8938-cafd80e9b13d.tabs.0.elements.0.max','null'),('entryTypes.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3.fieldLayouts.34818875-5fcc-49fe-8938-cafd80e9b13d.tabs.0.elements.0.min','null'),('entryTypes.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3.fieldLayouts.34818875-5fcc-49fe-8938-cafd80e9b13d.tabs.0.elements.0.name','null'),('entryTypes.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3.fieldLayouts.34818875-5fcc-49fe-8938-cafd80e9b13d.tabs.0.elements.0.orientation','null'),('entryTypes.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3.fieldLayouts.34818875-5fcc-49fe-8938-cafd80e9b13d.tabs.0.elements.0.placeholder','null'),('entryTypes.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3.fieldLayouts.34818875-5fcc-49fe-8938-cafd80e9b13d.tabs.0.elements.0.readonly','false'),('entryTypes.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3.fieldLayouts.34818875-5fcc-49fe-8938-cafd80e9b13d.tabs.0.elements.0.requirable','false'),('entryTypes.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3.fieldLayouts.34818875-5fcc-49fe-8938-cafd80e9b13d.tabs.0.elements.0.size','null'),('entryTypes.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3.fieldLayouts.34818875-5fcc-49fe-8938-cafd80e9b13d.tabs.0.elements.0.step','null'),('entryTypes.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3.fieldLayouts.34818875-5fcc-49fe-8938-cafd80e9b13d.tabs.0.elements.0.tip','null'),('entryTypes.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3.fieldLayouts.34818875-5fcc-49fe-8938-cafd80e9b13d.tabs.0.elements.0.title','null'),('entryTypes.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3.fieldLayouts.34818875-5fcc-49fe-8938-cafd80e9b13d.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3.fieldLayouts.34818875-5fcc-49fe-8938-cafd80e9b13d.tabs.0.elements.0.uid','\"fab76129-1bb9-477b-9a3a-89c09787b7cf\"'),('entryTypes.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3.fieldLayouts.34818875-5fcc-49fe-8938-cafd80e9b13d.tabs.0.elements.0.warning','null'),('entryTypes.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3.fieldLayouts.34818875-5fcc-49fe-8938-cafd80e9b13d.tabs.0.elements.0.width','100'),('entryTypes.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3.fieldLayouts.34818875-5fcc-49fe-8938-cafd80e9b13d.tabs.0.name','\"Content\"'),('entryTypes.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3.fieldLayouts.34818875-5fcc-49fe-8938-cafd80e9b13d.tabs.0.uid','\"adef476e-bd95-4481-a5c3-370694aeb628\"'),('entryTypes.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3.handle','\"default\"'),('entryTypes.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3.hasTitleField','true'),('entryTypes.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3.name','\"Default\"'),('entryTypes.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3.section','\"4ed30683-1a66-48b7-b6dd-0ab7ff4e6fce\"'),('entryTypes.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3.sortOrder','1'),('entryTypes.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3.titleFormat','null'),('entryTypes.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3.titleTranslationKeyFormat','null'),('entryTypes.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3.titleTranslationMethod','\"site\"'),('fieldGroups.54a3e6eb-0887-4880-a798-4bf78095795c.name','\"Meta\"'),('fieldGroups.f01d3ccf-b281-468d-8917-44495f1f7f66.name','\"Footer\"'),('fieldGroups.fefe114d-3863-429f-83c8-4e35865f3323.name','\"Common\"'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.columnSuffix','null'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.contentColumnType','\"string\"'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.fieldGroup','\"fefe114d-3863-429f-83c8-4e35865f3323\"'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.handle','\"navigationLogo\"'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.instructions','null'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.name','\"Navigation logo\"'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.searchable','false'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.settings.allowedKinds.0','\"image\"'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.settings.allowSelfRelations','false'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.settings.allowSubfolders','false'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.settings.allowUploads','true'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.settings.defaultUploadLocationSource','null'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.settings.defaultUploadLocationSubpath','null'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.settings.localizeRelations','false'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.settings.maxRelations','1'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.settings.minRelations','0'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.settings.previewMode','\"full\"'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.settings.restrictedDefaultUploadSubpath','null'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.settings.restrictedLocationSource','null'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.settings.restrictedLocationSubpath','null'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.settings.restrictFiles','true'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.settings.restrictLocation','false'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.settings.selectionCondition.__assoc__.0.0','\"elementType\"'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.settings.selectionCondition.__assoc__.0.1','\"craft\\\\elements\\\\Asset\"'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.settings.selectionCondition.__assoc__.1.0','\"fieldContext\"'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.settings.selectionCondition.__assoc__.1.1','\"global\"'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.settings.selectionCondition.__assoc__.2.0','\"class\"'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.settings.selectionCondition.__assoc__.2.1','\"craft\\\\elements\\\\conditions\\\\assets\\\\AssetCondition\"'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.settings.selectionLabel','null'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.settings.showSiteMenu','true'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.settings.showUnpermittedFiles','false'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.settings.showUnpermittedVolumes','false'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.settings.source','null'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.settings.sources','\"*\"'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.settings.targetSiteId','null'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.settings.validateRelatedElements','false'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.settings.viewMode','\"large\"'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.translationKeyFormat','null'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.translationMethod','\"site\"'),('fields.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345.type','\"craft\\\\fields\\\\Assets\"'),('fields.4f9488d6-5cba-4c4b-9126-4f6370d90690.columnSuffix','\"tzvpmbrm\"'),('fields.4f9488d6-5cba-4c4b-9126-4f6370d90690.contentColumnType','\"string(400)\"'),('fields.4f9488d6-5cba-4c4b-9126-4f6370d90690.fieldGroup','\"54a3e6eb-0887-4880-a798-4bf78095795c\"'),('fields.4f9488d6-5cba-4c4b-9126-4f6370d90690.handle','\"pageTitle\"'),('fields.4f9488d6-5cba-4c4b-9126-4f6370d90690.instructions','null'),('fields.4f9488d6-5cba-4c4b-9126-4f6370d90690.name','\"Page title\"'),('fields.4f9488d6-5cba-4c4b-9126-4f6370d90690.searchable','false'),('fields.4f9488d6-5cba-4c4b-9126-4f6370d90690.settings.byteLimit','null'),('fields.4f9488d6-5cba-4c4b-9126-4f6370d90690.settings.charLimit','100'),('fields.4f9488d6-5cba-4c4b-9126-4f6370d90690.settings.code','false'),('fields.4f9488d6-5cba-4c4b-9126-4f6370d90690.settings.columnType','null'),('fields.4f9488d6-5cba-4c4b-9126-4f6370d90690.settings.initialRows','4'),('fields.4f9488d6-5cba-4c4b-9126-4f6370d90690.settings.multiline','false'),('fields.4f9488d6-5cba-4c4b-9126-4f6370d90690.settings.placeholder','null'),('fields.4f9488d6-5cba-4c4b-9126-4f6370d90690.settings.uiMode','\"normal\"'),('fields.4f9488d6-5cba-4c4b-9126-4f6370d90690.translationKeyFormat','null'),('fields.4f9488d6-5cba-4c4b-9126-4f6370d90690.translationMethod','\"none\"'),('fields.4f9488d6-5cba-4c4b-9126-4f6370d90690.type','\"craft\\\\fields\\\\PlainText\"'),('fields.a29fa51b-961a-4881-b4b5-c3e066122601.columnSuffix','\"ipyidism\"'),('fields.a29fa51b-961a-4881-b4b5-c3e066122601.contentColumnType','\"string(800)\"'),('fields.a29fa51b-961a-4881-b4b5-c3e066122601.fieldGroup','\"54a3e6eb-0887-4880-a798-4bf78095795c\"'),('fields.a29fa51b-961a-4881-b4b5-c3e066122601.handle','\"metaDescription\"'),('fields.a29fa51b-961a-4881-b4b5-c3e066122601.instructions','null'),('fields.a29fa51b-961a-4881-b4b5-c3e066122601.name','\"Meta description\"'),('fields.a29fa51b-961a-4881-b4b5-c3e066122601.searchable','true'),('fields.a29fa51b-961a-4881-b4b5-c3e066122601.settings.byteLimit','null'),('fields.a29fa51b-961a-4881-b4b5-c3e066122601.settings.charLimit','200'),('fields.a29fa51b-961a-4881-b4b5-c3e066122601.settings.code','false'),('fields.a29fa51b-961a-4881-b4b5-c3e066122601.settings.columnType','null'),('fields.a29fa51b-961a-4881-b4b5-c3e066122601.settings.initialRows','4'),('fields.a29fa51b-961a-4881-b4b5-c3e066122601.settings.multiline','true'),('fields.a29fa51b-961a-4881-b4b5-c3e066122601.settings.placeholder','null'),('fields.a29fa51b-961a-4881-b4b5-c3e066122601.settings.uiMode','\"normal\"'),('fields.a29fa51b-961a-4881-b4b5-c3e066122601.translationKeyFormat','null'),('fields.a29fa51b-961a-4881-b4b5-c3e066122601.translationMethod','\"none\"'),('fields.a29fa51b-961a-4881-b4b5-c3e066122601.type','\"craft\\\\fields\\\\PlainText\"'),('fields.d885ca37-56ce-4d56-bb1a-2e36c1406997.columnSuffix','\"ozgqnamt\"'),('fields.d885ca37-56ce-4d56-bb1a-2e36c1406997.contentColumnType','\"text\"'),('fields.d885ca37-56ce-4d56-bb1a-2e36c1406997.fieldGroup','\"f01d3ccf-b281-468d-8917-44495f1f7f66\"'),('fields.d885ca37-56ce-4d56-bb1a-2e36c1406997.handle','\"copyright\"'),('fields.d885ca37-56ce-4d56-bb1a-2e36c1406997.instructions','null'),('fields.d885ca37-56ce-4d56-bb1a-2e36c1406997.name','\"Copyright\"'),('fields.d885ca37-56ce-4d56-bb1a-2e36c1406997.searchable','true'),('fields.d885ca37-56ce-4d56-bb1a-2e36c1406997.settings.byteLimit','null'),('fields.d885ca37-56ce-4d56-bb1a-2e36c1406997.settings.charLimit','null'),('fields.d885ca37-56ce-4d56-bb1a-2e36c1406997.settings.code','false'),('fields.d885ca37-56ce-4d56-bb1a-2e36c1406997.settings.columnType','null'),('fields.d885ca37-56ce-4d56-bb1a-2e36c1406997.settings.initialRows','4'),('fields.d885ca37-56ce-4d56-bb1a-2e36c1406997.settings.multiline','false'),('fields.d885ca37-56ce-4d56-bb1a-2e36c1406997.settings.placeholder','null'),('fields.d885ca37-56ce-4d56-bb1a-2e36c1406997.settings.uiMode','\"normal\"'),('fields.d885ca37-56ce-4d56-bb1a-2e36c1406997.translationKeyFormat','null'),('fields.d885ca37-56ce-4d56-bb1a-2e36c1406997.translationMethod','\"none\"'),('fields.d885ca37-56ce-4d56-bb1a-2e36c1406997.type','\"craft\\\\fields\\\\PlainText\"'),('fields.e6ea26c6-b576-4b94-8b94-222e4396c11a.columnSuffix','\"covufsov\"'),('fields.e6ea26c6-b576-4b94-8b94-222e4396c11a.contentColumnType','\"text\"'),('fields.e6ea26c6-b576-4b94-8b94-222e4396c11a.fieldGroup','\"54a3e6eb-0887-4880-a798-4bf78095795c\"'),('fields.e6ea26c6-b576-4b94-8b94-222e4396c11a.handle','\"metaKeywords\"'),('fields.e6ea26c6-b576-4b94-8b94-222e4396c11a.instructions','null'),('fields.e6ea26c6-b576-4b94-8b94-222e4396c11a.name','\"Meta keywords\"'),('fields.e6ea26c6-b576-4b94-8b94-222e4396c11a.searchable','true'),('fields.e6ea26c6-b576-4b94-8b94-222e4396c11a.settings.byteLimit','null'),('fields.e6ea26c6-b576-4b94-8b94-222e4396c11a.settings.charLimit','null'),('fields.e6ea26c6-b576-4b94-8b94-222e4396c11a.settings.code','false'),('fields.e6ea26c6-b576-4b94-8b94-222e4396c11a.settings.columnType','null'),('fields.e6ea26c6-b576-4b94-8b94-222e4396c11a.settings.initialRows','4'),('fields.e6ea26c6-b576-4b94-8b94-222e4396c11a.settings.multiline','false'),('fields.e6ea26c6-b576-4b94-8b94-222e4396c11a.settings.placeholder','\"tag, tag\"'),('fields.e6ea26c6-b576-4b94-8b94-222e4396c11a.settings.uiMode','\"normal\"'),('fields.e6ea26c6-b576-4b94-8b94-222e4396c11a.translationKeyFormat','null'),('fields.e6ea26c6-b576-4b94-8b94-222e4396c11a.translationMethod','\"none\"'),('fields.e6ea26c6-b576-4b94-8b94-222e4396c11a.type','\"craft\\\\fields\\\\PlainText\"'),('globalSets.a68d529a-4653-4b28-af35-6065e57e89f8.fieldLayouts.ef6432a7-e2f8-45e5-930d-0cee96b22bea.tabs.0.elements.0.fieldUid','\"4f9488d6-5cba-4c4b-9126-4f6370d90690\"'),('globalSets.a68d529a-4653-4b28-af35-6065e57e89f8.fieldLayouts.ef6432a7-e2f8-45e5-930d-0cee96b22bea.tabs.0.elements.0.instructions','null'),('globalSets.a68d529a-4653-4b28-af35-6065e57e89f8.fieldLayouts.ef6432a7-e2f8-45e5-930d-0cee96b22bea.tabs.0.elements.0.label','null'),('globalSets.a68d529a-4653-4b28-af35-6065e57e89f8.fieldLayouts.ef6432a7-e2f8-45e5-930d-0cee96b22bea.tabs.0.elements.0.required','false'),('globalSets.a68d529a-4653-4b28-af35-6065e57e89f8.fieldLayouts.ef6432a7-e2f8-45e5-930d-0cee96b22bea.tabs.0.elements.0.tip','null'),('globalSets.a68d529a-4653-4b28-af35-6065e57e89f8.fieldLayouts.ef6432a7-e2f8-45e5-930d-0cee96b22bea.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('globalSets.a68d529a-4653-4b28-af35-6065e57e89f8.fieldLayouts.ef6432a7-e2f8-45e5-930d-0cee96b22bea.tabs.0.elements.0.uid','\"7215f315-e5c6-4519-aeb5-ea17a92d5c17\"'),('globalSets.a68d529a-4653-4b28-af35-6065e57e89f8.fieldLayouts.ef6432a7-e2f8-45e5-930d-0cee96b22bea.tabs.0.elements.0.warning','null'),('globalSets.a68d529a-4653-4b28-af35-6065e57e89f8.fieldLayouts.ef6432a7-e2f8-45e5-930d-0cee96b22bea.tabs.0.elements.0.width','100'),('globalSets.a68d529a-4653-4b28-af35-6065e57e89f8.fieldLayouts.ef6432a7-e2f8-45e5-930d-0cee96b22bea.tabs.0.elements.1.fieldUid','\"a29fa51b-961a-4881-b4b5-c3e066122601\"'),('globalSets.a68d529a-4653-4b28-af35-6065e57e89f8.fieldLayouts.ef6432a7-e2f8-45e5-930d-0cee96b22bea.tabs.0.elements.1.instructions','null'),('globalSets.a68d529a-4653-4b28-af35-6065e57e89f8.fieldLayouts.ef6432a7-e2f8-45e5-930d-0cee96b22bea.tabs.0.elements.1.label','null'),('globalSets.a68d529a-4653-4b28-af35-6065e57e89f8.fieldLayouts.ef6432a7-e2f8-45e5-930d-0cee96b22bea.tabs.0.elements.1.required','false'),('globalSets.a68d529a-4653-4b28-af35-6065e57e89f8.fieldLayouts.ef6432a7-e2f8-45e5-930d-0cee96b22bea.tabs.0.elements.1.tip','null'),('globalSets.a68d529a-4653-4b28-af35-6065e57e89f8.fieldLayouts.ef6432a7-e2f8-45e5-930d-0cee96b22bea.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('globalSets.a68d529a-4653-4b28-af35-6065e57e89f8.fieldLayouts.ef6432a7-e2f8-45e5-930d-0cee96b22bea.tabs.0.elements.1.uid','\"b5c7adc8-2f5d-44fd-9228-6b98b284922c\"'),('globalSets.a68d529a-4653-4b28-af35-6065e57e89f8.fieldLayouts.ef6432a7-e2f8-45e5-930d-0cee96b22bea.tabs.0.elements.1.warning','null'),('globalSets.a68d529a-4653-4b28-af35-6065e57e89f8.fieldLayouts.ef6432a7-e2f8-45e5-930d-0cee96b22bea.tabs.0.elements.1.width','100'),('globalSets.a68d529a-4653-4b28-af35-6065e57e89f8.fieldLayouts.ef6432a7-e2f8-45e5-930d-0cee96b22bea.tabs.0.elements.2.fieldUid','\"e6ea26c6-b576-4b94-8b94-222e4396c11a\"'),('globalSets.a68d529a-4653-4b28-af35-6065e57e89f8.fieldLayouts.ef6432a7-e2f8-45e5-930d-0cee96b22bea.tabs.0.elements.2.instructions','null'),('globalSets.a68d529a-4653-4b28-af35-6065e57e89f8.fieldLayouts.ef6432a7-e2f8-45e5-930d-0cee96b22bea.tabs.0.elements.2.label','null'),('globalSets.a68d529a-4653-4b28-af35-6065e57e89f8.fieldLayouts.ef6432a7-e2f8-45e5-930d-0cee96b22bea.tabs.0.elements.2.required','false'),('globalSets.a68d529a-4653-4b28-af35-6065e57e89f8.fieldLayouts.ef6432a7-e2f8-45e5-930d-0cee96b22bea.tabs.0.elements.2.tip','null'),('globalSets.a68d529a-4653-4b28-af35-6065e57e89f8.fieldLayouts.ef6432a7-e2f8-45e5-930d-0cee96b22bea.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('globalSets.a68d529a-4653-4b28-af35-6065e57e89f8.fieldLayouts.ef6432a7-e2f8-45e5-930d-0cee96b22bea.tabs.0.elements.2.uid','\"77bbd686-6fc5-4d7e-a769-9cfb6771a6f4\"'),('globalSets.a68d529a-4653-4b28-af35-6065e57e89f8.fieldLayouts.ef6432a7-e2f8-45e5-930d-0cee96b22bea.tabs.0.elements.2.warning','null'),('globalSets.a68d529a-4653-4b28-af35-6065e57e89f8.fieldLayouts.ef6432a7-e2f8-45e5-930d-0cee96b22bea.tabs.0.elements.2.width','100'),('globalSets.a68d529a-4653-4b28-af35-6065e57e89f8.fieldLayouts.ef6432a7-e2f8-45e5-930d-0cee96b22bea.tabs.0.name','\"Header\"'),('globalSets.a68d529a-4653-4b28-af35-6065e57e89f8.fieldLayouts.ef6432a7-e2f8-45e5-930d-0cee96b22bea.tabs.0.uid','\"f4dba190-5dfe-4bdc-9abb-4e8678f57422\"'),('globalSets.a68d529a-4653-4b28-af35-6065e57e89f8.handle','\"header\"'),('globalSets.a68d529a-4653-4b28-af35-6065e57e89f8.name','\"Header\"'),('globalSets.a68d529a-4653-4b28-af35-6065e57e89f8.sortOrder','1'),('globalSets.cedde99d-71a7-4a93-ba03-0d1aebdc2157.fieldLayouts.dff92c0e-282b-41c8-bbee-65d9eb00f727.tabs.0.elements.0.fieldUid','\"41bf28b7-1ee9-4ef5-9b7a-17dd9926e345\"'),('globalSets.cedde99d-71a7-4a93-ba03-0d1aebdc2157.fieldLayouts.dff92c0e-282b-41c8-bbee-65d9eb00f727.tabs.0.elements.0.instructions','null'),('globalSets.cedde99d-71a7-4a93-ba03-0d1aebdc2157.fieldLayouts.dff92c0e-282b-41c8-bbee-65d9eb00f727.tabs.0.elements.0.label','null'),('globalSets.cedde99d-71a7-4a93-ba03-0d1aebdc2157.fieldLayouts.dff92c0e-282b-41c8-bbee-65d9eb00f727.tabs.0.elements.0.required','false'),('globalSets.cedde99d-71a7-4a93-ba03-0d1aebdc2157.fieldLayouts.dff92c0e-282b-41c8-bbee-65d9eb00f727.tabs.0.elements.0.tip','null'),('globalSets.cedde99d-71a7-4a93-ba03-0d1aebdc2157.fieldLayouts.dff92c0e-282b-41c8-bbee-65d9eb00f727.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('globalSets.cedde99d-71a7-4a93-ba03-0d1aebdc2157.fieldLayouts.dff92c0e-282b-41c8-bbee-65d9eb00f727.tabs.0.elements.0.uid','\"398fd1b9-1da0-4b02-a491-04f4df5894c9\"'),('globalSets.cedde99d-71a7-4a93-ba03-0d1aebdc2157.fieldLayouts.dff92c0e-282b-41c8-bbee-65d9eb00f727.tabs.0.elements.0.warning','null'),('globalSets.cedde99d-71a7-4a93-ba03-0d1aebdc2157.fieldLayouts.dff92c0e-282b-41c8-bbee-65d9eb00f727.tabs.0.elements.0.width','100'),('globalSets.cedde99d-71a7-4a93-ba03-0d1aebdc2157.fieldLayouts.dff92c0e-282b-41c8-bbee-65d9eb00f727.tabs.0.name','\"Navigation\"'),('globalSets.cedde99d-71a7-4a93-ba03-0d1aebdc2157.fieldLayouts.dff92c0e-282b-41c8-bbee-65d9eb00f727.tabs.0.uid','\"c0230390-018b-4e77-99f1-b4174c03a852\"'),('globalSets.cedde99d-71a7-4a93-ba03-0d1aebdc2157.handle','\"navigation\"'),('globalSets.cedde99d-71a7-4a93-ba03-0d1aebdc2157.name','\"Navigation\"'),('globalSets.cedde99d-71a7-4a93-ba03-0d1aebdc2157.sortOrder','3'),('globalSets.f4e805a9-9a81-4e4c-9e7d-16508454929c.fieldLayouts.7a952482-636d-4693-8042-b850b9dfc0a0.tabs.0.elements.0.fieldUid','\"d885ca37-56ce-4d56-bb1a-2e36c1406997\"'),('globalSets.f4e805a9-9a81-4e4c-9e7d-16508454929c.fieldLayouts.7a952482-636d-4693-8042-b850b9dfc0a0.tabs.0.elements.0.instructions','null'),('globalSets.f4e805a9-9a81-4e4c-9e7d-16508454929c.fieldLayouts.7a952482-636d-4693-8042-b850b9dfc0a0.tabs.0.elements.0.label','null'),('globalSets.f4e805a9-9a81-4e4c-9e7d-16508454929c.fieldLayouts.7a952482-636d-4693-8042-b850b9dfc0a0.tabs.0.elements.0.required','false'),('globalSets.f4e805a9-9a81-4e4c-9e7d-16508454929c.fieldLayouts.7a952482-636d-4693-8042-b850b9dfc0a0.tabs.0.elements.0.tip','null'),('globalSets.f4e805a9-9a81-4e4c-9e7d-16508454929c.fieldLayouts.7a952482-636d-4693-8042-b850b9dfc0a0.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('globalSets.f4e805a9-9a81-4e4c-9e7d-16508454929c.fieldLayouts.7a952482-636d-4693-8042-b850b9dfc0a0.tabs.0.elements.0.uid','\"1ab418c4-0d70-44cb-b3d5-8cd802d7fefc\"'),('globalSets.f4e805a9-9a81-4e4c-9e7d-16508454929c.fieldLayouts.7a952482-636d-4693-8042-b850b9dfc0a0.tabs.0.elements.0.warning','null'),('globalSets.f4e805a9-9a81-4e4c-9e7d-16508454929c.fieldLayouts.7a952482-636d-4693-8042-b850b9dfc0a0.tabs.0.elements.0.width','100'),('globalSets.f4e805a9-9a81-4e4c-9e7d-16508454929c.fieldLayouts.7a952482-636d-4693-8042-b850b9dfc0a0.tabs.0.name','\"Footer\"'),('globalSets.f4e805a9-9a81-4e4c-9e7d-16508454929c.fieldLayouts.7a952482-636d-4693-8042-b850b9dfc0a0.tabs.0.uid','\"f12ebd1c-c99f-4919-91ab-f1b3bf0a9c1f\"'),('globalSets.f4e805a9-9a81-4e4c-9e7d-16508454929c.handle','\"footer\"'),('globalSets.f4e805a9-9a81-4e4c-9e7d-16508454929c.name','\"Footer\"'),('globalSets.f4e805a9-9a81-4e4c-9e7d-16508454929c.sortOrder','2'),('graphql.schemas.9e149db2-cbf2-4d0c-be84-673c44cf446e.isPublic','true'),('graphql.schemas.9e149db2-cbf2-4d0c-be84-673c44cf446e.name','\"Public Schema\"'),('meta.__names__.067b8079-ff86-45ca-b67b-b25b54f4245b','\"Navigation links\"'),('meta.__names__.1c798ff3-3767-4943-af6a-f95199053004','\"Default\"'),('meta.__names__.2c1a6abd-a5ca-4a8c-8997-08da2721ba09','\"Form submissions\"'),('meta.__names__.301ad900-b843-483c-8c76-5a17b02fee48','\"Primary footer links\"'),('meta.__names__.38ac5001-1c65-41e7-bafb-0a90d162acb5','\"Default\"'),('meta.__names__.41bf28b7-1ee9-4ef5-9b7a-17dd9926e345','\"Navigation logo\"'),('meta.__names__.4ed30683-1a66-48b7-b6dd-0ab7ff4e6fce','\"Forms\"'),('meta.__names__.4f9488d6-5cba-4c4b-9126-4f6370d90690','\"Page title\"'),('meta.__names__.54a3e6eb-0887-4880-a798-4bf78095795c','\"Meta\"'),('meta.__names__.7b181e68-36eb-4de8-bb15-c9bbe13bdc0a','\"Default\"'),('meta.__names__.9e149db2-cbf2-4d0c-be84-673c44cf446e','\"Public Schema\"'),('meta.__names__.9e490732-1ad8-42dd-9afc-522d8283631c','\"Craft 4 Starter\"'),('meta.__names__.a29fa51b-961a-4881-b4b5-c3e066122601','\"Meta description\"'),('meta.__names__.a68d529a-4653-4b28-af35-6065e57e89f8','\"Header\"'),('meta.__names__.befee4b8-d4d1-4f12-b1b4-a813ee7c48ac','\"Default\"'),('meta.__names__.c51a1d73-ff0d-4e87-bc02-619ac167057c','\"Secondary footer links\"'),('meta.__names__.c835f74b-1a83-4ed8-9190-4c7cc5e5aae3','\"Default\"'),('meta.__names__.cedde99d-71a7-4a93-ba03-0d1aebdc2157','\"Navigation\"'),('meta.__names__.d885ca37-56ce-4d56-bb1a-2e36c1406997','\"Copyright\"'),('meta.__names__.e6ea26c6-b576-4b94-8b94-222e4396c11a','\"Meta keywords\"'),('meta.__names__.f01d3ccf-b281-468d-8917-44495f1f7f66','\"Footer\"'),('meta.__names__.f4e805a9-9a81-4e4c-9e7d-16508454929c','\"Footer\"'),('meta.__names__.f9b32916-2126-4e45-a11f-04f0e7ca7a39','\"Main\"'),('meta.__names__.fefe114d-3863-429f-83c8-4e35865f3323','\"Common\"'),('plugins.imager-x.edition','\"lite\"'),('plugins.imager-x.enabled','true'),('plugins.imager-x.licenseKey','\"TG6IEXHAXN7T5Q8GCUD9BRJ7\"'),('plugins.imager-x.schemaVersion','\"4.0.0\"'),('sections.067b8079-ff86-45ca-b67b-b25b54f4245b.defaultPlacement','\"end\"'),('sections.067b8079-ff86-45ca-b67b-b25b54f4245b.enableVersioning','true'),('sections.067b8079-ff86-45ca-b67b-b25b54f4245b.handle','\"navigationLinks\"'),('sections.067b8079-ff86-45ca-b67b-b25b54f4245b.name','\"Navigation links\"'),('sections.067b8079-ff86-45ca-b67b-b25b54f4245b.propagationMethod','\"all\"'),('sections.067b8079-ff86-45ca-b67b-b25b54f4245b.siteSettings.9e490732-1ad8-42dd-9afc-522d8283631c.enabledByDefault','true'),('sections.067b8079-ff86-45ca-b67b-b25b54f4245b.siteSettings.9e490732-1ad8-42dd-9afc-522d8283631c.hasUrls','false'),('sections.067b8079-ff86-45ca-b67b-b25b54f4245b.siteSettings.9e490732-1ad8-42dd-9afc-522d8283631c.template','null'),('sections.067b8079-ff86-45ca-b67b-b25b54f4245b.siteSettings.9e490732-1ad8-42dd-9afc-522d8283631c.uriFormat','null'),('sections.067b8079-ff86-45ca-b67b-b25b54f4245b.structure.maxLevels','1'),('sections.067b8079-ff86-45ca-b67b-b25b54f4245b.structure.uid','\"72614f92-0ade-46f1-8aae-eafbde9eb444\"'),('sections.067b8079-ff86-45ca-b67b-b25b54f4245b.type','\"structure\"'),('sections.2c1a6abd-a5ca-4a8c-8997-08da2721ba09.defaultPlacement','\"end\"'),('sections.2c1a6abd-a5ca-4a8c-8997-08da2721ba09.enableVersioning','true'),('sections.2c1a6abd-a5ca-4a8c-8997-08da2721ba09.handle','\"formSubmissions\"'),('sections.2c1a6abd-a5ca-4a8c-8997-08da2721ba09.name','\"Form submissions\"'),('sections.2c1a6abd-a5ca-4a8c-8997-08da2721ba09.propagationMethod','\"all\"'),('sections.2c1a6abd-a5ca-4a8c-8997-08da2721ba09.siteSettings.9e490732-1ad8-42dd-9afc-522d8283631c.enabledByDefault','true'),('sections.2c1a6abd-a5ca-4a8c-8997-08da2721ba09.siteSettings.9e490732-1ad8-42dd-9afc-522d8283631c.hasUrls','false'),('sections.2c1a6abd-a5ca-4a8c-8997-08da2721ba09.siteSettings.9e490732-1ad8-42dd-9afc-522d8283631c.template','null'),('sections.2c1a6abd-a5ca-4a8c-8997-08da2721ba09.siteSettings.9e490732-1ad8-42dd-9afc-522d8283631c.uriFormat','null'),('sections.2c1a6abd-a5ca-4a8c-8997-08da2721ba09.type','\"channel\"'),('sections.301ad900-b843-483c-8c76-5a17b02fee48.defaultPlacement','\"end\"'),('sections.301ad900-b843-483c-8c76-5a17b02fee48.enableVersioning','true'),('sections.301ad900-b843-483c-8c76-5a17b02fee48.handle','\"primaryFooterLinks\"'),('sections.301ad900-b843-483c-8c76-5a17b02fee48.name','\"Primary footer links\"'),('sections.301ad900-b843-483c-8c76-5a17b02fee48.propagationMethod','\"all\"'),('sections.301ad900-b843-483c-8c76-5a17b02fee48.siteSettings.9e490732-1ad8-42dd-9afc-522d8283631c.enabledByDefault','true'),('sections.301ad900-b843-483c-8c76-5a17b02fee48.siteSettings.9e490732-1ad8-42dd-9afc-522d8283631c.hasUrls','false'),('sections.301ad900-b843-483c-8c76-5a17b02fee48.siteSettings.9e490732-1ad8-42dd-9afc-522d8283631c.template','null'),('sections.301ad900-b843-483c-8c76-5a17b02fee48.siteSettings.9e490732-1ad8-42dd-9afc-522d8283631c.uriFormat','null'),('sections.301ad900-b843-483c-8c76-5a17b02fee48.structure.maxLevels','1'),('sections.301ad900-b843-483c-8c76-5a17b02fee48.structure.uid','\"359fb3d5-a0ef-481d-ad5c-4e77460d667e\"'),('sections.301ad900-b843-483c-8c76-5a17b02fee48.type','\"structure\"'),('sections.4ed30683-1a66-48b7-b6dd-0ab7ff4e6fce.defaultPlacement','\"end\"'),('sections.4ed30683-1a66-48b7-b6dd-0ab7ff4e6fce.enableVersioning','true'),('sections.4ed30683-1a66-48b7-b6dd-0ab7ff4e6fce.handle','\"forms\"'),('sections.4ed30683-1a66-48b7-b6dd-0ab7ff4e6fce.name','\"Forms\"'),('sections.4ed30683-1a66-48b7-b6dd-0ab7ff4e6fce.propagationMethod','\"all\"'),('sections.4ed30683-1a66-48b7-b6dd-0ab7ff4e6fce.siteSettings.9e490732-1ad8-42dd-9afc-522d8283631c.enabledByDefault','true'),('sections.4ed30683-1a66-48b7-b6dd-0ab7ff4e6fce.siteSettings.9e490732-1ad8-42dd-9afc-522d8283631c.hasUrls','false'),('sections.4ed30683-1a66-48b7-b6dd-0ab7ff4e6fce.siteSettings.9e490732-1ad8-42dd-9afc-522d8283631c.template','null'),('sections.4ed30683-1a66-48b7-b6dd-0ab7ff4e6fce.siteSettings.9e490732-1ad8-42dd-9afc-522d8283631c.uriFormat','null'),('sections.4ed30683-1a66-48b7-b6dd-0ab7ff4e6fce.type','\"channel\"'),('sections.c51a1d73-ff0d-4e87-bc02-619ac167057c.defaultPlacement','\"end\"'),('sections.c51a1d73-ff0d-4e87-bc02-619ac167057c.enableVersioning','true'),('sections.c51a1d73-ff0d-4e87-bc02-619ac167057c.handle','\"secondaryFooterLinks\"'),('sections.c51a1d73-ff0d-4e87-bc02-619ac167057c.name','\"Secondary footer links\"'),('sections.c51a1d73-ff0d-4e87-bc02-619ac167057c.propagationMethod','\"all\"'),('sections.c51a1d73-ff0d-4e87-bc02-619ac167057c.siteSettings.9e490732-1ad8-42dd-9afc-522d8283631c.enabledByDefault','true'),('sections.c51a1d73-ff0d-4e87-bc02-619ac167057c.siteSettings.9e490732-1ad8-42dd-9afc-522d8283631c.hasUrls','false'),('sections.c51a1d73-ff0d-4e87-bc02-619ac167057c.siteSettings.9e490732-1ad8-42dd-9afc-522d8283631c.template','null'),('sections.c51a1d73-ff0d-4e87-bc02-619ac167057c.siteSettings.9e490732-1ad8-42dd-9afc-522d8283631c.uriFormat','null'),('sections.c51a1d73-ff0d-4e87-bc02-619ac167057c.structure.maxLevels','null'),('sections.c51a1d73-ff0d-4e87-bc02-619ac167057c.structure.uid','\"1a07243c-8a18-4998-9d80-618b3b22a90c\"'),('sections.c51a1d73-ff0d-4e87-bc02-619ac167057c.type','\"structure\"'),('siteGroups.f9b32916-2126-4e45-a11f-04f0e7ca7a39.name','\"Main\"'),('sites.9e490732-1ad8-42dd-9afc-522d8283631c.baseUrl','\"$PRIMARY_SITE_URL\"'),('sites.9e490732-1ad8-42dd-9afc-522d8283631c.enabled','true'),('sites.9e490732-1ad8-42dd-9afc-522d8283631c.handle','\"en\"'),('sites.9e490732-1ad8-42dd-9afc-522d8283631c.hasUrls','true'),('sites.9e490732-1ad8-42dd-9afc-522d8283631c.language','\"en-ZA\"'),('sites.9e490732-1ad8-42dd-9afc-522d8283631c.name','\"Craft 4 Starter\"'),('sites.9e490732-1ad8-42dd-9afc-522d8283631c.primary','true'),('sites.9e490732-1ad8-42dd-9afc-522d8283631c.siteGroup','\"f9b32916-2126-4e45-a11f-04f0e7ca7a39\"'),('sites.9e490732-1ad8-42dd-9afc-522d8283631c.sortOrder','1'),('system.edition','\"pro\"'),('system.live','true'),('system.name','\"Craft 4 Starter\"'),('system.retryDuration','null'),('system.schemaVersion','\"4.0.0.9\"'),('system.timeZone','\"Africa/Johannesburg\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.requireEmailVerification','true');
/*!40000 ALTER TABLE `craft_projectconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_queue`
--

DROP TABLE IF EXISTS `craft_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `craft_idx_bmqjpqawmwhbvwpzzpvfnamitpuaitskhjbh` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `craft_idx_tfmgxustbqpiqnwgmmcacjmzicqzqzswmweo` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_queue`
--

LOCK TABLES `craft_queue` WRITE;
/*!40000 ALTER TABLE `craft_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_relations`
--

DROP TABLE IF EXISTS `craft_relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_mhavdimlglbgxxmdifhuwkcbirhzcextkjod` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `craft_idx_jbtmbxexylpgjwlkcnoncvjzklxvycbgbaok` (`sourceId`),
  KEY `craft_idx_umqfnkhinobzhmgmhssbtqbrfuidkwwqqhdg` (`targetId`),
  KEY `craft_idx_vmfmsiqeywcqodbmugngktcxsggxdgobrgmo` (`sourceSiteId`),
  CONSTRAINT `craft_fk_bsimhluelwiqckzidoowccaaouoqppshcxsd` FOREIGN KEY (`targetId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_jogtjitrpisjcgvjrcrduwlzmruicorrwjvv` FOREIGN KEY (`sourceSiteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_fk_labrpcbzeqdwlluklpsfoikpnadbbvipejwr` FOREIGN KEY (`sourceId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_tmeogwthvywuisspkjifoxykvuggngamzcfg` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_relations`
--

LOCK TABLES `craft_relations` WRITE;
/*!40000 ALTER TABLE `craft_relations` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_resourcepaths`
--

DROP TABLE IF EXISTS `craft_resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_resourcepaths`
--

LOCK TABLES `craft_resourcepaths` WRITE;
/*!40000 ALTER TABLE `craft_resourcepaths` DISABLE KEYS */;
INSERT INTO `craft_resourcepaths` VALUES ('1245492b','@craft/web/assets/htmx/dist'),('1781ba2d','@craft/web/assets/xregexp/dist'),('1c39072d','@craft/web/assets/picturefill/dist'),('1d94c8d7','@craft/web/assets/edituser/dist'),('20310291','@craft/web/assets/jquerytouchevents/dist'),('2062ddf3','@craft/web/assets/jquerypayment/dist'),('23eccbf9','@bower/jquery/dist'),('25f5df44','@craft/web/assets/velocity/dist'),('260cd411','@craft/web/assets/elementresizedetector/dist'),('290b5bef','@craft/web/assets/jqueryui/dist'),('2d68baf','@storage/rebrand/logo'),('2e695434','@craft/web/assets/datepickeri18n/dist'),('31d5071f','@craft/web/assets/vue/dist'),('37708d44','@craft/web/assets/fileupload/dist'),('3f4294f2','@craft/web/assets/updates/dist'),('40c5d02b','@craft/web/assets/craftsupport/dist'),('42a107ef','@craft/web/assets/xregexp/dist'),('4919baef','@craft/web/assets/picturefill/dist'),('62503086','@craft/web/assets/fileupload/dist'),('64ad4a82','@craft/web/assets/editsection/dist'),('64f5badd','@craft/web/assets/vue/dist'),('661b46a3','@storage/rebrand/icon'),('693cba4','@craft/web/assets/dashboard/dist'),('6a622930','@craft/web/assets/updates/dist'),('70d56286','@craft/web/assets/velocity/dist'),('732c69d3','@craft/web/assets/elementresizedetector/dist'),('7511bf53','@craft/web/assets/jquerytouchevents/dist'),('75426031','@craft/web/assets/jquerypayment/dist'),('76cc763b','@bower/jquery/dist'),('7b49e9f6','@craft/web/assets/datepickeri18n/dist'),('7c2be62d','@craft/web/assets/jqueryui/dist'),('7fd0ed6f','@craft/web/assets/feed/dist'),('94064cd7','@craft/web/assets/axios/dist'),('9f7d6650','@craft/web/assets/garnish/dist'),('a14c720c','@craft/web/assets/pluginstore/dist'),('a36a5a1b','@craft/web/assets/tailwindreset/dist'),('a47fe039','@craft/web/assets/selectize/dist'),('a7e5c779','@craft/web/assets/utilities/dist'),('a8374271','@craft/web/assets/cp/dist'),('aaccf1ea','@craft/web/assets/focusvisible/dist'),('b0715d3e','@storage/rebrand/logo'),('b2026438','@craft/web/assets/d3/dist'),('b7cf5147','@craft/web/assets/fabric/dist'),('b93d555a','@craft/web/assets/sites/dist'),('b9636d8f','@craft/web/assets/iframeresizer/dist'),('c126f115','@craft/web/assets/axios/dist'),('c67e7ab0','@storage/rebrand/icon'),('ca5ddb92','@craft/web/assets/garnish/dist'),('d0102213','@craft/web/assets/updater/dist'),('d1f386b7','@storage/rebrand/icon'),('d9d3644c','@craft/web/assets/recententries/dist'),('da540c18','@craft/web/assets/conditionbuilder/dist'),('e2efec85','@craft/web/assets/fabric/dist'),('e722d9fa','@craft/web/assets/d3/dist'),('e7692622','@craft/web/assets/updateswidget/dist'),('ea2a057b','@craft/web/assets/fieldsettings/dist'),('ec43d04d','@craft/web/assets/iframeresizer/dist'),('edf2217b','@storage/rebrand/logo'),('ee467279','@craft/web/assets/generalsettings/dist'),('f15f5dfb','@craft/web/assets/selectize/dist'),('f2c57abb','@craft/web/assets/utilities/dist'),('f46ccfce','@craft/web/assets/pluginstore/dist'),('f64ae7d9','@craft/web/assets/tailwindreset/dist'),('fd17ffb3','@craft/web/assets/cp/dist'),('ffec4c28','@craft/web/assets/focusvisible/dist');
/*!40000 ALTER TABLE `craft_resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_revisions`
--

DROP TABLE IF EXISTS `craft_revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_melqjmfhcamnuazfxgtxntoxhtcigpujwhgc` (`canonicalId`,`num`),
  KEY `craft_fk_asblhvncgifcqvxdpsbqbrxaiimcwvvhrwcd` (`creatorId`),
  CONSTRAINT `craft_fk_asblhvncgifcqvxdpsbqbrxaiimcwvvhrwcd` FOREIGN KEY (`creatorId`) REFERENCES `craft_users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_fk_zfvqkmfdaznrpeqfhjawgklcpxwvuvcbtbsi` FOREIGN KEY (`canonicalId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_revisions`
--

LOCK TABLES `craft_revisions` WRITE;
/*!40000 ALTER TABLE `craft_revisions` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_searchindex`
--

DROP TABLE IF EXISTS `craft_searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `craft_idx_isdhkwlryvexuisnbieqvcecpivczwynmsuj` (`keywords`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_searchindex`
--

LOCK TABLES `craft_searchindex` WRITE;
/*!40000 ALTER TABLE `craft_searchindex` DISABLE KEYS */;
INSERT INTO `craft_searchindex` VALUES (1,'username',0,1,' adminflow '),(1,'fullname',0,1,' flow communications '),(1,'firstname',0,1,' flow '),(2,'slug',0,1,''),(1,'lastname',0,1,' communications '),(1,'email',0,1,' admin flowsa com '),(1,'slug',0,1,''),(3,'slug',0,1,''),(4,'slug',0,1,'');
/*!40000 ALTER TABLE `craft_searchindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_sections`
--

DROP TABLE IF EXISTS `craft_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_vfxmnkcjtgijqtamkasknobopyadnigfqqno` (`handle`),
  KEY `craft_idx_bfnkztmtaiqxhzqgttwwqgsqkosiwyfbcplt` (`name`),
  KEY `craft_idx_asqubecsfgyywgxlwupiaczucssqtarzeglt` (`structureId`),
  KEY `craft_idx_hsosjqwrodofotgwnggfpuqpprxhcywwsajc` (`dateDeleted`),
  CONSTRAINT `craft_fk_dqngbutlgfonudcibwksclkpvbuudugvslua` FOREIGN KEY (`structureId`) REFERENCES `craft_structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_sections`
--

LOCK TABLES `craft_sections` WRITE;
/*!40000 ALTER TABLE `craft_sections` DISABLE KEYS */;
INSERT INTO `craft_sections` VALUES (1,1,'Primary footer links','primaryFooterLinks','structure',1,'all','end',NULL,'2022-06-28 12:59:37','2022-06-28 12:59:37',NULL,'301ad900-b843-483c-8c76-5a17b02fee48'),(2,2,'Secondary footer links','secondaryFooterLinks','structure',1,'all','end',NULL,'2022-06-28 13:00:49','2022-06-28 13:00:49',NULL,'c51a1d73-ff0d-4e87-bc02-619ac167057c'),(3,3,'Header links','headerLinks','structure',1,'all','end',NULL,'2022-06-28 13:02:47','2022-06-28 13:02:47','2022-06-28 13:03:15','b8cb0b6d-76d9-4055-8482-bcad9e8e5562'),(4,4,'Navigation links','navigationLinks','structure',1,'all','end',NULL,'2022-06-28 13:03:59','2022-06-28 13:05:41',NULL,'067b8079-ff86-45ca-b67b-b25b54f4245b'),(5,NULL,'Forms','forms','channel',1,'all','end',NULL,'2022-06-28 13:07:58','2022-06-28 13:07:58',NULL,'4ed30683-1a66-48b7-b6dd-0ab7ff4e6fce'),(6,NULL,'Form submissions','formSubmissions','channel',1,'all','end',NULL,'2022-06-28 13:08:39','2022-06-28 13:18:44',NULL,'2c1a6abd-a5ca-4a8c-8997-08da2721ba09');
/*!40000 ALTER TABLE `craft_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_sections_sites`
--

DROP TABLE IF EXISTS `craft_sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_xirvoyzhrtuvmveqirvasgnrpfdcqykrhvha` (`sectionId`,`siteId`),
  KEY `craft_idx_wsqdngjdiccrodqldljtdqusmdmefjdwzkfy` (`siteId`),
  CONSTRAINT `craft_fk_plpwrlewfsazvnsdwwxvjsjsvafwdcpeeled` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_fk_ueeildeoneylqblfqjxdjlinuidgcozmqrju` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_sections_sites`
--

LOCK TABLES `craft_sections_sites` WRITE;
/*!40000 ALTER TABLE `craft_sections_sites` DISABLE KEYS */;
INSERT INTO `craft_sections_sites` VALUES (1,1,1,0,NULL,NULL,1,'2022-06-28 12:59:37','2022-06-28 12:59:37','5b296a20-0169-49ca-9a27-fc983cfe6c0a'),(2,2,1,0,NULL,NULL,1,'2022-06-28 13:00:49','2022-06-28 13:00:49','7aefea7d-abd5-41ea-8d94-721834334c73'),(3,3,1,0,NULL,NULL,1,'2022-06-28 13:02:47','2022-06-28 13:02:47','705faf46-85f5-45c5-81c2-7f3ef3fae555'),(4,4,1,0,NULL,NULL,1,'2022-06-28 13:03:59','2022-06-28 13:03:59','60f28e1e-ccf8-4293-8ae4-3fb8224e4779'),(5,5,1,0,NULL,NULL,1,'2022-06-28 13:07:58','2022-06-28 13:07:58','a1731b8e-70ea-458d-9dc6-2fa7e133d8ef'),(6,6,1,0,NULL,NULL,1,'2022-06-28 13:08:39','2022-06-28 13:08:39','fb473a8b-1a89-4189-9ff9-bb633b7047b5');
/*!40000 ALTER TABLE `craft_sections_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_sequences`
--

DROP TABLE IF EXISTS `craft_sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_sequences` (
  `name` varchar(255) NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_sequences`
--

LOCK TABLES `craft_sequences` WRITE;
/*!40000 ALTER TABLE `craft_sequences` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_sessions`
--

DROP TABLE IF EXISTS `craft_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_hlxutqtsjydhhypdwbvajqgzkzmaptsofcad` (`uid`),
  KEY `craft_idx_sxjzatraloabnkjtprwqovfkufrdqosfwmth` (`token`),
  KEY `craft_idx_zjlnnvknzcivwzzupmjypnnxyxxyfqqvbjbr` (`dateUpdated`),
  KEY `craft_idx_ixjlgmdynlpqdgigfzasoolgounyjlegzukk` (`userId`),
  CONSTRAINT `craft_fk_zwzyxydrvryfvtdxydrqfuapbsdagmejtvvw` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_sessions`
--

LOCK TABLES `craft_sessions` WRITE;
/*!40000 ALTER TABLE `craft_sessions` DISABLE KEYS */;
INSERT INTO `craft_sessions` VALUES (3,1,'kjeQ6rhKeLdQVBwD45W1CttUMeBSAmTpk80nVrg5P3xQze2J92CtSYtHvTjYGu827ERTDauhe0c7E3sn-0qN4WWnhI-c4DzI87mY','2022-06-28 12:52:48','2022-06-28 13:28:00','4c95dde5-ac09-476c-be14-eabf04913c82'),(4,1,'2CYvuFdo3Hm5ZSm2Pm7H1eStugWbujuYLYVP4DoWVjRdX25LTTQt-hd5NXQZRyRWh0HwsIzE-yoVQdYDmcbXPxB9xjOz27hAFlV3','2022-06-30 09:12:32','2022-06-30 09:52:39','72e09aa2-1647-43fe-afec-7a473178f7f4');
/*!40000 ALTER TABLE `craft_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_shunnedmessages`
--

DROP TABLE IF EXISTS `craft_shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_hnlxuaoywedddazymnwkblsscsjkkrbvthkq` (`userId`,`message`),
  CONSTRAINT `craft_fk_xucxfuynkboxeswwbvqtqtszuhfopozaoqvw` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_shunnedmessages`
--

LOCK TABLES `craft_shunnedmessages` WRITE;
/*!40000 ALTER TABLE `craft_shunnedmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_sitegroups`
--

DROP TABLE IF EXISTS `craft_sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_mimgnyammelxxslimykulglahfyykilneays` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_sitegroups`
--

LOCK TABLES `craft_sitegroups` WRITE;
/*!40000 ALTER TABLE `craft_sitegroups` DISABLE KEYS */;
INSERT INTO `craft_sitegroups` VALUES (1,'Main','2022-06-28 11:36:44','2022-06-28 12:31:38',NULL,'f9b32916-2126-4e45-a11f-04f0e7ca7a39');
/*!40000 ALTER TABLE `craft_sitegroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_sites`
--

DROP TABLE IF EXISTS `craft_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(12) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_kjojivaxbbzitgifxedyhdyzthavturgcfud` (`dateDeleted`),
  KEY `craft_idx_cklacbfbtssqtrjgpzpdbhtykffkwklpvuuq` (`handle`),
  KEY `craft_idx_sbduvrxsnmruukfrafizodxlzrbflemrcmiv` (`sortOrder`),
  KEY `craft_fk_vxtcyvscurmroewbyqvydxaxwldjggurnxbd` (`groupId`),
  CONSTRAINT `craft_fk_vxtcyvscurmroewbyqvydxaxwldjggurnxbd` FOREIGN KEY (`groupId`) REFERENCES `craft_sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_sites`
--

LOCK TABLES `craft_sites` WRITE;
/*!40000 ALTER TABLE `craft_sites` DISABLE KEYS */;
INSERT INTO `craft_sites` VALUES (1,1,1,'1','Craft 4 Starter','en','en-ZA',1,'$PRIMARY_SITE_URL',1,'2022-06-28 11:36:44','2022-06-28 12:32:03',NULL,'9e490732-1ad8-42dd-9afc-522d8283631c');
/*!40000 ALTER TABLE `craft_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_structureelements`
--

DROP TABLE IF EXISTS `craft_structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_bmrczswuzjerukzovkaooxqfchsyqnxxluha` (`structureId`,`elementId`),
  KEY `craft_idx_zilahfyxtkuyylwqfeqpdmnuzlilpfwteyxm` (`root`),
  KEY `craft_idx_otqunmoyjhxfwhzvspeafuszyizyhwamdqyp` (`lft`),
  KEY `craft_idx_wybsgavpwxsmylhttrkqsrsnyuwxenfarlgd` (`rgt`),
  KEY `craft_idx_ffsdldfsplrzlxqiwkxlmimcmmcmgrzgmnmd` (`level`),
  KEY `craft_idx_onrpnigqmvhrgjnbwyshyecguaygzldpxicn` (`elementId`),
  CONSTRAINT `craft_fk_wlrvoutbilmtyxkhqyywtktxvxmgptmokavk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_xmwrruwblibwzaetkjqxzotivocvxuvkfxly` FOREIGN KEY (`structureId`) REFERENCES `craft_structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_structureelements`
--

LOCK TABLES `craft_structureelements` WRITE;
/*!40000 ALTER TABLE `craft_structureelements` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_structureelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_structures`
--

DROP TABLE IF EXISTS `craft_structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_ajqebwvxirphhmvejtiqwmlcrrcbalmqebmt` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_structures`
--

LOCK TABLES `craft_structures` WRITE;
/*!40000 ALTER TABLE `craft_structures` DISABLE KEYS */;
INSERT INTO `craft_structures` VALUES (1,1,'2022-06-28 12:59:37','2022-06-28 12:59:37',NULL,'359fb3d5-a0ef-481d-ad5c-4e77460d667e'),(2,NULL,'2022-06-28 13:00:49','2022-06-28 13:00:49',NULL,'1a07243c-8a18-4998-9d80-618b3b22a90c'),(3,1,'2022-06-28 13:02:47','2022-06-28 13:02:47','2022-06-28 13:03:15','55d35efb-c92a-4496-afb7-9311b8d85557'),(4,1,'2022-06-28 13:03:59','2022-06-28 13:03:59',NULL,'72614f92-0ade-46f1-8aae-eafbde9eb444');
/*!40000 ALTER TABLE `craft_structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_systemmessages`
--

DROP TABLE IF EXISTS `craft_systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_yirgfwitofyikzzypbrkwvfupxnilvezgtwl` (`key`,`language`),
  KEY `craft_idx_uwujrqbojctndqgcwfpaxjgsfdgugcggbjan` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_systemmessages`
--

LOCK TABLES `craft_systemmessages` WRITE;
/*!40000 ALTER TABLE `craft_systemmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_systemmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_taggroups`
--

DROP TABLE IF EXISTS `craft_taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_grzeldmlhkfaaiqvgoczxrsmdyergplruosv` (`name`),
  KEY `craft_idx_playxfarekmyoorlcrndunmqlssxrclvzqca` (`handle`),
  KEY `craft_idx_ubvyjhevipcovnowlwdcfcmiwqiyeznrvuyn` (`dateDeleted`),
  KEY `craft_fk_fsyapebamwrszfpfwombitxhblktmwthfisw` (`fieldLayoutId`),
  CONSTRAINT `craft_fk_fsyapebamwrszfpfwombitxhblktmwthfisw` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_taggroups`
--

LOCK TABLES `craft_taggroups` WRITE;
/*!40000 ALTER TABLE `craft_taggroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_taggroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_tags`
--

DROP TABLE IF EXISTS `craft_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `craft_idx_zyacwfgffpwdnznxxoagjgeerdkgchwextwy` (`groupId`),
  CONSTRAINT `craft_fk_xeucwdhkastbucrggnxjvriuloqypwgjsmrd` FOREIGN KEY (`groupId`) REFERENCES `craft_taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_yqsxfxuoqqrhyibgsdyoezpqpgrkwmsyxram` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_tags`
--

LOCK TABLES `craft_tags` WRITE;
/*!40000 ALTER TABLE `craft_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_tokens`
--

DROP TABLE IF EXISTS `craft_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_iswwheeprbnptowymjuwkuxbaflebtyjulkt` (`token`),
  KEY `craft_idx_vipftfeoquapdekxwregqfkqfokuhjusnjgr` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_tokens`
--

LOCK TABLES `craft_tokens` WRITE;
/*!40000 ALTER TABLE `craft_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_usergroups`
--

DROP TABLE IF EXISTS `craft_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_xflnhjcvvcgrzvyittzgzhkdcaerysdtkyje` (`handle`),
  KEY `craft_idx_ggzstwqiqivskoajrdsocjbnlyzlxbtttqdx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_usergroups`
--

LOCK TABLES `craft_usergroups` WRITE;
/*!40000 ALTER TABLE `craft_usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_usergroups_users`
--

DROP TABLE IF EXISTS `craft_usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_nqeoidwzxuvixmzqdxalgqkcgzjfrlztgcap` (`groupId`,`userId`),
  KEY `craft_idx_hwtneikoqinjgxyntmhecopprkjfkbqbkqkr` (`userId`),
  CONSTRAINT `craft_fk_uvbbuloienltxqgqrfqasmalgjeqnniruqkn` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_ykoavrebzgjcyzetkuupsimsguuggpjlwrhy` FOREIGN KEY (`groupId`) REFERENCES `craft_usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_usergroups_users`
--

LOCK TABLES `craft_usergroups_users` WRITE;
/*!40000 ALTER TABLE `craft_usergroups_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_userpermissions`
--

DROP TABLE IF EXISTS `craft_userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_btggugmgmtemhbwejhcxmpyhfomfzjgamwii` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_userpermissions`
--

LOCK TABLES `craft_userpermissions` WRITE;
/*!40000 ALTER TABLE `craft_userpermissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_userpermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_userpermissions_usergroups`
--

DROP TABLE IF EXISTS `craft_userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_momymnaymkgvvcwrrfdycopzyhmnvszqcqnx` (`permissionId`,`groupId`),
  KEY `craft_idx_jtyholshaucdimkoiqcycercdsivfrmhduoi` (`groupId`),
  CONSTRAINT `craft_fk_keiaenbidnicmoqvttjprawfntllrgjfpzip` FOREIGN KEY (`permissionId`) REFERENCES `craft_userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_ujhssrhrueidsdtqjodozmwgifctidmixtnd` FOREIGN KEY (`groupId`) REFERENCES `craft_usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_userpermissions_usergroups`
--

LOCK TABLES `craft_userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `craft_userpermissions_usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_userpermissions_users`
--

DROP TABLE IF EXISTS `craft_userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_ulkpoofutbcukaocbamcivlsjyjwyiksncsn` (`permissionId`,`userId`),
  KEY `craft_idx_idlpzfogbtjbwcxxicafbsdksxmhcvymfdda` (`userId`),
  CONSTRAINT `craft_fk_kiapmpqtkypfqqhcaqysrupgntwdlxnfzmmf` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_qupuzbuqjokojilmrztgoklrohdfwvqpfvml` FOREIGN KEY (`permissionId`) REFERENCES `craft_userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_userpermissions_users`
--

LOCK TABLES `craft_userpermissions_users` WRITE;
/*!40000 ALTER TABLE `craft_userpermissions_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_userpreferences`
--

DROP TABLE IF EXISTS `craft_userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` text,
  PRIMARY KEY (`userId`),
  CONSTRAINT `craft_fk_dsubtylguxiymbxdavgargirmbgrlqoebrmx` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_userpreferences`
--

LOCK TABLES `craft_userpreferences` WRITE;
/*!40000 ALTER TABLE `craft_userpreferences` DISABLE KEYS */;
INSERT INTO `craft_userpreferences` VALUES (1,'{\"language\":\"en-GB\",\"locale\":null,\"weekStartDay\":\"1\",\"alwaysShowFocusRings\":false,\"useShapes\":false,\"underlineLinks\":false,\"showFieldHandles\":false,\"enableDebugToolbarForSite\":false,\"enableDebugToolbarForCp\":false,\"showExceptionView\":false,\"profileTemplates\":false}');
/*!40000 ALTER TABLE `craft_userpreferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_users`
--

DROP TABLE IF EXISTS `craft_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `craft_idx_sxridbopqsqewvaswkxfqpyjkxqsafqypkoz` (`active`),
  KEY `craft_idx_ibjsunnffwqfhxuvhyndykynwjfmtfixblod` (`locked`),
  KEY `craft_idx_tnjgwdyendoyzvksuoqkpreivjclnyurpxac` (`pending`),
  KEY `craft_idx_kmswvqpllvmybxsfqdthjudnugjcxjpsixcv` (`suspended`),
  KEY `craft_idx_qiwuzeeubqxrictaoweqfcgabwfrbcjaevhs` (`verificationCode`),
  KEY `craft_idx_qjjvkgcjplfpjmdasikvyrybonxlilvxsxij` (`email`),
  KEY `craft_idx_ycfcdegcswkenhdzullzwmdqkrkweupxrsro` (`username`),
  KEY `craft_fk_dtoubtujdzxlkzayfvlgjpqizhncvuwepffa` (`photoId`),
  CONSTRAINT `craft_fk_dtoubtujdzxlkzayfvlgjpqizhncvuwepffa` FOREIGN KEY (`photoId`) REFERENCES `craft_assets` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_fk_ujwoayngtbzvcbqkywajyrngetbzipsjmsxy` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_users`
--

LOCK TABLES `craft_users` WRITE;
/*!40000 ALTER TABLE `craft_users` DISABLE KEYS */;
INSERT INTO `craft_users` VALUES (1,NULL,1,0,0,0,1,'adminflow','Flow Communications','Flow','Communications','admin@flowsa.com','$2y$13$vQd2cmUUfJ4MvGuSvRWHkeaz3omATzjPvUrDgeKq/CES5MA9lsUg.','2022-06-30 09:12:32',NULL,NULL,NULL,'2022-06-30 09:11:54',NULL,1,NULL,NULL,NULL,0,'2022-06-28 11:36:45','2022-06-28 11:36:45','2022-06-30 09:12:32');
/*!40000 ALTER TABLE `craft_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_volumefolders`
--

DROP TABLE IF EXISTS `craft_volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_idx_gbwjgqjcsasepkqnwodgmilsvhleyvvnoref` (`name`,`parentId`,`volumeId`),
  KEY `craft_idx_gnlkuelkxidicbtkdjywamxydwgihsnpdfnv` (`parentId`),
  KEY `craft_idx_ribogarlvzsnmfvoykmruepjjfmmanotarxx` (`volumeId`),
  CONSTRAINT `craft_fk_clsmgazdhhwoifwzwnwsesluxcdvjbqlylis` FOREIGN KEY (`parentId`) REFERENCES `craft_volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fk_pvmzuqamoluhrenmeeiovseaofmczhatusot` FOREIGN KEY (`volumeId`) REFERENCES `craft_volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_volumefolders`
--

LOCK TABLES `craft_volumefolders` WRITE;
/*!40000 ALTER TABLE `craft_volumefolders` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_volumefolders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_volumes`
--

DROP TABLE IF EXISTS `craft_volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_eqepumlulohssrjbmmavfnxblzbontqkvzkv` (`name`),
  KEY `craft_idx_olbhecxkqelijlqrknkhkmvejhkudsyaaseg` (`handle`),
  KEY `craft_idx_oslgmxwaghzyxzqzzdwerritnmietpezgujx` (`fieldLayoutId`),
  KEY `craft_idx_xuhbulnrpcsgojlmpclfheqgrmrkuqnrnqkk` (`dateDeleted`),
  CONSTRAINT `craft_fk_utremoqalnnfwpszdmybueffsefqivorlmhj` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_volumes`
--

LOCK TABLES `craft_volumes` WRITE;
/*!40000 ALTER TABLE `craft_volumes` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_volumes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_widgets`
--

DROP TABLE IF EXISTS `craft_widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craft_widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` text,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_idx_wondnksspenzyvciuaoaktkahssjebkwenrj` (`userId`),
  CONSTRAINT `craft_fk_qrfhgaianbcxqaabyqefxlkkvdrscgxnqrrt` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_widgets`
--

LOCK TABLES `craft_widgets` WRITE;
/*!40000 ALTER TABLE `craft_widgets` DISABLE KEYS */;
INSERT INTO `craft_widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',2,2,'{\"siteId\":1,\"section\":\"*\",\"limit\":10}',1,'2022-06-28 11:39:24','2022-06-28 12:56:42','4fa9433a-ccc1-4118-9d8d-fd25ede2b795'),(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2022-06-28 11:39:24','2022-06-28 11:39:24','46bbacc6-ce49-4ba9-9f5f-5a7d6fb2bf3b'),(5,1,'craft\\widgets\\MyDrafts',1,2,'{\"limit\":10}',1,'2022-06-28 12:55:56','2022-06-28 12:56:42','2baa4005-88ba-421b-9441-2875a9ff35e5');
/*!40000 ALTER TABLE `craft_widgets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-30  9:53:24
